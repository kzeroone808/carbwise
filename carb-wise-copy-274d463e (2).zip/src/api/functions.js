import { base44 } from './base44Client';


export const createCheckoutSession = base44.functions.createCheckoutSession;

export const stripeWebhook = base44.functions.stripeWebhook;

export const verifySubscription = base44.functions.verifySubscription;

export const manageSubscription = base44.functions.manageSubscription;

export const testCGMConnection = base44.functions.testCGMConnection;

export const fetchCGMData = base44.functions.fetchCGMData;

export const setupAdmin = base44.functions.setupAdmin;

export const scrapeNutrislice = base44.functions.scrapeNutrislice;

