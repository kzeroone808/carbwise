import { base44 } from './base44Client';


export const FoodItem = base44.entities.FoodItem;

export const Meal = base44.entities.Meal;



// auth sdk:
export const User = base44.auth;