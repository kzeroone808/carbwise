
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { FoodItem, Meal, User } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, ChefHat, PlusCircle, UploadCloud, Crown } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import RestaurantGrid from "../components/calculator/RestaurantGrid";
import CategoryFilter from "../components/calculator/CategoryFilter";
import FoodItemCard from "../components/calculator/FoodItemCard";
import CartSidebar from "../components/calculator/CartSidebar";
import CustomItemForm from "../components/calculator/CustomItemForm";
import Toast from "../components/ui/toast";
import BolusCalculator from "../components/calculator/BolusCalculator";
import UpgradePrompt from "../components/premium/UpgradePrompt";
import StreakCounter from "../components/gamification/StreakCounter";
import RealtimeBGDisplay from "../components/core/RealtimeBGDisplay";
import GlucoseAI from "../components/ai/GlucoseAI";
import SmartAlerts from "../components/ai/SmartAlerts";

export default function Calculator() {
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [foodItems, setFoodItems] = useState([]);
  const [cart, setCart] = useState([]);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showCustomItemDialog, setShowCustomItemDialog] = useState(false);
  const [showBolusCalculator, setShowBolusCalculator] = useState(false);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);
  const [requiredTier, setRequiredTier] = useState(null);
  const [mealName, setMealName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [userTier, setUserTier] = useState("free");
  const [userStreak, setUserStreak] = useState(0);
  const [totalMeals, setTotalMeals] = useState(0);
  const [latestBgReading, setLatestBgReading] = useState(null); // Handles { value, trend, timestamp }
  const [showAIAnalysis, setShowAIAnalysis] = useState(false);
  const [previousBG, setPreviousBG] = useState(null);
  const [selectedRestaurants, setSelectedRestaurants] = useState([]);

  const totals = useMemo(() => {
    const totalCarbs = cart.reduce((sum, item) => sum + item.carbs * item.quantity, 0);
    const totalCalories = cart.reduce((sum, item) => sum + item.calories * item.quantity, 0);
    return { carbs: totalCarbs, calories: totalCalories };
  }, [cart]);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const user = await User.me();
      if (user) {
        setUserTier(user.subscriptionStatus || "free");
        setUserStreak(user.dailyStreak || 0);
        setTotalMeals(user.totalMealsLogged || 0);
        setSelectedRestaurants(user.selectedRestaurants || []);
      }
    } catch (error) {
      console.log("User not logged in or data unavailable");
    }
  };

  const loadFoodItems = useCallback(async () => {
    if (!selectedRestaurant) return;
    setIsLoading(true);
    try {
      const genericItems = await FoodItem.filter({ restaurant: selectedRestaurant, is_custom: false });
      
      let allItems = genericItems;
      try {
        const user = await User.me();
        if(user) {
          const customItems = await FoodItem.filter({ 
            restaurant: selectedRestaurant, 
            is_custom: true, 
            created_by: user.email 
          });
          allItems = [...genericItems, ...customItems];
        }
      } catch (e) {
        console.warn("Failed to fetch user or custom items, proceeding with generic items only:", e);
      }

      setFoodItems(allItems.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      console.error("Error loading food items:", error);
      setFoodItems([]);
    }
    setIsLoading(false);
  }, [selectedRestaurant]);

  useEffect(() => {
    loadFoodItems();
  }, [loadFoodItems]);

  const filteredItems = foodItems.filter(item => {
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory || (selectedCategory === "custom" && item.is_custom);
    const matchesSearch = !searchTerm || item.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleRestaurantSelect = (restaurantId) => {
    // Premium Plus users should have unlimited access to all restaurants
    if (userTier === 'premium_plus') {
      setSelectedRestaurant(restaurantId);
      return;
    }
    
    // For other tiers, check if restaurant is in their selected list
    if (!selectedRestaurants.includes(restaurantId)) {
      // Show upgrade prompt if they try to select a restaurant they haven't picked
      setShowUpgradePrompt(true);
      setRequiredTier(userTier === 'free' ? 'premium' : 'premium_plus');
      return;
    }
    
    setSelectedRestaurant(restaurantId);
  };

  const handleUpgrade = (shouldUpgrade) => {
    setShowUpgradePrompt(false);
  };

  const addToCart = (item, size, sizeData) => {
    const existingItemIndex = cart.findIndex(cartItem => cartItem.food_item_id === item.id && cartItem.size === size);

    if (existingItemIndex > -1) {
      updateQuantity(existingItemIndex, cart[existingItemIndex].quantity + 1);
    } else {
      const cartItem = {
        food_item_id: item.id,
        name: item.name,
        size: size,
        carbs: sizeData.carbs,
        calories: sizeData.calories,
        quantity: 1
      };
      setCart(prev => [...prev, cartItem]);
    }
    setToastMessage(`${item.name} added to your meal! 🍽️`);
  };

  const updateQuantity = (index, newQuantity) => {
    setCart(prev => prev.map((item, i) => 
      i === index ? { ...item, quantity: newQuantity } : item
    ));
  };

  const removeItem = (index) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const clearCart = () => {
    setCart([]);
  };

  const handleSaveMeal = async (details) => {
    const { name, suggestedBolus } = details;
    if (!name || cart.length === 0) return;

    const mealData = {
      name: name,
      restaurant: selectedRestaurant,
      items: cart,
      total_carbs: totals.carbs,
      total_calories: totals.calories,
      meal_date: new Date().toISOString().split('T')[0],
      suggested_bolus: suggestedBolus || null
    };

    try {
      await Meal.create(mealData);
      
      const newTotalMeals = totalMeals + 1;
      const newStreak = calculateStreak();
      await User.updateMyUserData({
        totalMealsLogged: newTotalMeals,
        dailyStreak: newStreak,
        lastLoginDate: new Date().toISOString().split('T')[0]
      });
      
      setTotalMeals(newTotalMeals);
      setUserStreak(newStreak);
      setToastMessage("Meal saved successfully! 🎉 Keep up the great tracking!");
      
      setCart([]);
      setMealName("");
      setShowSaveDialog(false);
      setShowBolusCalculator(false);
    } catch (error) {
      console.error("Error saving meal:", error);
      setToastMessage("Error saving meal. Please try again.");
    }
  };

  const calculateStreak = () => {
    return userStreak + 1;
  };
  
  return (
    <>
      <Toast message={toastMessage} onDismiss={() => setToastMessage('')} />
      
      {/* Smart Alerts for all Tiers - component handles logic */}
      <SmartAlerts 
        currentBG={latestBgReading?.value} 
        trend={latestBgReading?.trend} 
        previousBG={previousBG}
        userTier={userTier}
      />

      {showUpgradePrompt && (
        <UpgradePrompt 
          requiredTier={requiredTier}
          onUpgrade={handleUpgrade}
        />
      )}
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                  <ChefHat className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">CarbWise Calculator</h1>
                  <p className="text-gray-600">Smart carb tracking for better diabetes management</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button asChild variant="outline" className="hover:bg-blue-50 relative">
                  <Link to={createPageUrl("MenuImporter")}>
                    <UploadCloud className="w-4 h-4 mr-2" />
                    Import Menu
                    {userTier === 'free' && (
                      <Crown className="w-3 h-3 absolute -top-1 -right-1 text-yellow-600" />
                    )}
                  </Link>
                </Button>
              </div>
            </div>
          </div>

          {/* Realtime BG and Streak Counter - BG Display is now for all tiers */}
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <RealtimeBGDisplay 
              onReadingUpdate={(newReading) => {
                if (newReading) {
                  setPreviousBG(latestBgReading?.value);
                }
                setLatestBgReading(newReading);
              }}
              onShowAI={() => {
                if (userTier === 'premium_plus') {
                  setShowAIAnalysis(true);
                } else {
                  setShowUpgradePrompt(true);
                  setRequiredTier('premium_plus');
                }
              }}
              userTier={userTier}
            />
            <StreakCounter streak={userStreak} totalMeals={totalMeals} />
          </div>

          {/* AI Glucose Analysis - Premium Plus Only */}
          {showAIAnalysis && latestBgReading && userTier === 'premium_plus' && (
            <div className="mb-6">
              <GlucoseAI 
                currentBG={latestBgReading.value}
                trend={latestBgReading.trend}
                recentReadings={[previousBG, latestBgReading.value].filter(val => val !== null)}
              />
            </div>
          )}

          {!selectedRestaurant ? (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Choose Your Restaurant</h2>
              <RestaurantGrid 
                onSelectRestaurant={handleRestaurantSelect}
                selectedRestaurant={selectedRestaurant}
                selectedRestaurants={selectedRestaurants}
                userTier={userTier}
              />
            </div>
          ) : (
            <div className="grid lg:grid-cols-4 gap-8">
              <div className="lg:col-span-3 space-y-6">
                <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedRestaurant(null);
                        setCart([]);
                      }}
                      className="hover:bg-blue-50"
                    >
                      ← Back to Restaurants
                    </Button>
                    <h2 className="text-xl font-semibold text-gray-900 capitalize">
                      {selectedRestaurant.replace(/_/g, ' ')} Menu
                    </h2>
                  </div>
                  
                  <div className="relative w-full md:w-80">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search menu items..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                  <CategoryFilter
                    selectedCategory={selectedCategory}
                    onSelectCategory={setSelectedCategory}
                  />
                  <Button 
                    variant="outline" 
                    onClick={() => setShowCustomItemDialog(true)}
                    className="w-full sm:w-auto hover:bg-green-50 hover:text-green-700"
                  >
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Add Custom Item
                  </Button>
                </div>

                {isLoading ? (
                  <div className="grid md:grid-cols-2 gap-4">
                    {Array(6).fill(0).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-gray-200 h-48 rounded-lg"></div>
                      </div>
                    ))}
                  </div>
                ) : filteredItems.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500 text-lg">No items found</p>
                    <p className="text-gray-400">Try adjusting your filters or search</p>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-4">
                    {filteredItems.map((item) => (
                      <FoodItemCard
                        key={item.id}
                        item={item}
                        onAddToCart={addToCart}
                      />
                    ))}
                  </div>
                )}
              </div>

              <div className="lg:col-span-1">
                <CartSidebar
                  cart={cart}
                  totals={totals}
                  onUpdateQuantity={updateQuantity}
                  onRemoveItem={removeItem}
                  onSaveMeal={() => setShowSaveDialog(true)}
                  onClearCart={clearCart}
                  onCalculateDose={() => setShowBolusCalculator(true)}
                />
              </div>
            </div>
          )}

          <CustomItemForm 
            open={showCustomItemDialog}
            onOpenChange={setShowCustomItemDialog}
            onSuccess={() => {
              setShowCustomItemDialog(false);
              loadFoodItems();
              setToastMessage("Custom item added! 🎉");
            }}
            restaurant={selectedRestaurant}
          />

          <BolusCalculator
              open={showBolusCalculator}
              onOpenChange={setShowBolusCalculator}
              totalCarbs={totals.carbs}
              latestBG={latestBgReading?.value}
              onSave={(dose) => {
                  const defaultName = `${selectedRestaurant.replace(/_/g, ' ')} Meal - ${new Date().toLocaleDateString()}`;
                  handleSaveMeal({ name: defaultName, suggestedBolus: dose });
              }}
              userTier={userTier}
          />

          <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Save Your Meal 🍽️</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <Label htmlFor="meal-name">Meal Name</Label>
                <Input
                  id="meal-name"
                  placeholder="e.g., Lunch at McDonald's"
                  value={mealName}
                  onChange={(e) => setMealName(e.target.value)}
                />
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowSaveDialog(false)}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => handleSaveMeal({ name: mealName })}
                  disabled={!mealName.trim()}
                  className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                >
                  Save Meal
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </>
  );
}
