import Layout from "./Layout.jsx";

import Calculator from "./Calculator";

import MealHistory from "./MealHistory";

import Settings from "./Settings";

import MenuImporter from "./MenuImporter";

import Pricing from "./Pricing";

import PaymentSuccess from "./PaymentSuccess";

import CGMSettings from "./CGMSettings";

import Index from "./Index";

import Home from "./Home";

import LiveMenu from "./LiveMenu";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Calculator: Calculator,
    
    MealHistory: MealHistory,
    
    Settings: Settings,
    
    MenuImporter: MenuImporter,
    
    Pricing: Pricing,
    
    PaymentSuccess: PaymentSuccess,
    
    CGMSettings: CGMSettings,
    
    Index: Index,
    
    Home: Home,
    
    LiveMenu: LiveMenu,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Calculator />} />
                
                
                <Route path="/Calculator" element={<Calculator />} />
                
                <Route path="/MealHistory" element={<MealHistory />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/MenuImporter" element={<MenuImporter />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/PaymentSuccess" element={<PaymentSuccess />} />
                
                <Route path="/CGMSettings" element={<CGMSettings />} />
                
                <Route path="/Index" element={<Index />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/LiveMenu" element={<LiveMenu />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}