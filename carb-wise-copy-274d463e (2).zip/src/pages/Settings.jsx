
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import Toast from "@/components/ui/toast";
import { Loader2 } from 'lucide-react';
import { manageSubscription } from '@/api/functions';
import { Badge } from "@/components/ui/badge";
import { setupAdmin } from "@/api/functions"; // New import

export default function Settings() {
  const [icr, setIcr] = useState('');
  const [isf, setIsf] = useState('');
  const [targetBG, setTargetBG] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [user, setUser] = useState(null);
  const [isManaging, setIsManaging] = useState(false);
  const [isSettingUpAdmin, setIsSettingUpAdmin] = useState(false); // New state

  // Refactored loadUserSettings to be accessible by other functions
  const loadUserSettings = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      setIcr(userData.insulinToCarbRatio || '');
      setIsf(userData.insulinSensitivityFactor || '');
      setTargetBG(userData.targetBloodGlucose || '');
    } catch (error) {
      console.error("Failed to load user settings:", error);
      // Optionally set a toast message for loading error
      setToastMessage("Failed to load user settings.");
    }
  };

  useEffect(() => {
    loadUserSettings();
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await User.updateMyUserData({
        insulinToCarbRatio: parseFloat(icr),
        insulinSensitivityFactor: parseFloat(isf),
        targetBloodGlucose: parseFloat(targetBG),
      });
      setToastMessage("Settings saved successfully!");
    } catch (error) {
      console.error("Failed to save settings:", error);
      setToastMessage("Error saving settings.");
    }
    setIsSaving(false);
  };
  
  const handleManageSubscription = async () => {
    setIsManaging(true);
    try {
      const { data } = await manageSubscription();
      if (data && data.url) {
        window.location.href = data.url;
      } else {
        throw new Error(data.error || "Could not open billing portal.");
      }
    } catch (error) {
      console.error(error);
      setToastMessage(`Error: ${error.message}`); // Use toast for error messages
    } finally {
      setIsManaging(false);
    }
  };

  // New handleSetupAdmin function
  const handleSetupAdmin = async () => {
    setIsSettingUpAdmin(true);
    try {
      const { data } = await setupAdmin();
      if (data && data.success) {
        setToastMessage("Admin privileges granted! Refresh the page to see changes.");
        // Reload user data to reflect admin status if applicable
        await loadUserSettings();
      } else {
        throw new Error("Failed to setup admin privileges");
      }
    } catch (error) {
      console.error("Admin setup error:", error);
      setToastMessage("Error setting up admin privileges.");
    } finally {
      setIsSettingUpAdmin(false);
    }
  };

  return (
    <>
      <Toast message={toastMessage} onDismiss={() => setToastMessage('')} />
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">My Settings</h1>
            <p className="text-gray-600">Manage your personal information and application preferences.</p>
          </div>

          {/* Add Admin Setup Card */}
          <Card>
            <CardHeader>
              <CardTitle>Developer Access</CardTitle>
              <CardDescription>
                Grant yourself admin privileges and full access to all features.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={handleSetupAdmin} 
                disabled={isSettingUpAdmin}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isSettingUpAdmin ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Setting up...
                  </>
                ) : (
                  'Grant Admin Access'
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Insulin Dosing Ratios</CardTitle>
              <CardDescription>
                These values are crucial for accurate insulin dose calculations. Please consult your doctor for these numbers.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="icr">Insulin-to-Carb Ratio (ICR)</Label>
                <Input id="icr" type="number" placeholder="e.g., 10" value={icr} onChange={e => setIcr(e.target.value)} />
                <p className="text-xs text-gray-500 mt-1">1 unit of insulin covers how many grams of carbs?</p>
              </div>
              <div>
                <Label htmlFor="isf">Insulin Sensitivity Factor (ISF)</Label>
                <Input id="isf" type="number" placeholder="e.g., 50" value={isf} onChange={e => setIsf(e.target.value)} />
                <p className="text-xs text-gray-500 mt-1">1 unit of insulin lowers BG by how many mg/dL?</p>
              </div>
              <div>
                <Label htmlFor="target-bg">Target Blood Glucose (BG)</Label>
                <Input id="target-bg" type="number" placeholder="e.g., 100" value={targetBG} onChange={e => setTargetBG(e.target.value)} />
                <p className="text-xs text-gray-500 mt-1">What is your ideal target BG in mg/dL?</p>
              </div>
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSaving ? "Saving..." : "Save Dosing Settings"}
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Subscription Management</CardTitle>
              <CardDescription>
                Your current plan is: <Badge className="capitalize">{user?.subscriptionStatus || 'free'}</Badge>.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">
                Manage your subscription, view invoices, and update your payment method through our secure billing portal.
              </p>
              <Button onClick={handleManageSubscription} disabled={isManaging || !user?.stripeCustomerId}>
                {isManaging ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : ''}
                {isManaging ? 'Redirecting...' : 'Manage Billing & Subscription'}
              </Button>
            </CardContent>
          </Card>

        </div>
      </div>
    </>
  );
}
