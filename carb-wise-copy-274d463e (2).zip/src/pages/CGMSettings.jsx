
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle, AlertCircle, Smartphone, Globe, Zap, ExternalLink, Star } from "lucide-react";
import { testCGMConnection } from "@/api/functions";
import Toast from "@/components/ui/toast";

export default function CGMSettings() {
  const [user, setUser] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('not_connected');
  const [toastMessage, setToastMessage] = useState('');
  
  // Dexcom Share settings
  const [dexcomUsername, setDexcomUsername] = useState('');
  const [dexcomPassword, setDexcomPassword] = useState('');
  const [dexcomServer, setDexcomServer] = useState('us');
  
  // Nightscout settings
  const [nightscoutUrl, setNightscoutUrl] = useState('');
  const [nightscoutToken, setNightscoutToken] = useState('');
  
  // Manual entry
  const [manualBG, setManualBG] = useState('');
  
  const [selectedMethod, setSelectedMethod] = useState('nightscout');

  useEffect(() => {
    loadUserSettings();
  }, []);

  const loadUserSettings = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.cgmSettings) {
        const settings = userData.cgmSettings;
        setSelectedMethod(settings.method || 'nightscout');
        setConnectionStatus(settings.status || 'not_connected');
        
        if (settings.method === 'dexcom_share') {
          setDexcomUsername(settings.username || '');
          setDexcomServer(settings.server || 'us');
        } else if (settings.method === 'nightscout') {
          setNightscoutUrl(settings.url || '');
        }
      }
    } catch (error) {
      console.error("Failed to load user settings:", error);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const cgmSettings = {
        method: selectedMethod,
        status: 'not_tested',
        lastUpdated: new Date().toISOString()
      };

      if (selectedMethod === 'dexcom_share') {
        if (!dexcomUsername || !dexcomPassword) {
          setToastMessage("Please enter both username and password");
          setIsSaving(false);
          return;
        }
        cgmSettings.username = dexcomUsername;
        cgmSettings.server = dexcomServer;
        cgmSettings.passwordHash = btoa(dexcomPassword);
      } else if (selectedMethod === 'nightscout') {
        if (!nightscoutUrl) {
          setToastMessage("Please enter your Nightscout URL");
          setIsSaving(false);
          return;
        }
        cgmSettings.url = nightscoutUrl;
        if (nightscoutToken) {
          cgmSettings.tokenHash = btoa(nightscoutToken);
        }
      } else if (selectedMethod === 'manual') {
        cgmSettings.lastManualEntry = manualBG;
        cgmSettings.lastManualTime = new Date().toISOString();
      }

      await User.updateMyUserData({ cgmSettings });
      setConnectionStatus('not_tested');
      setToastMessage("Settings saved successfully!");
    } catch (error) {
      console.error("Failed to save settings:", error);
      setToastMessage("Error saving settings. Please try again.");
    }
    setIsSaving(false);
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    try {
      const { data } = await testCGMConnection();
      
      if (data.success) {
        setConnectionStatus('connected');
        await User.updateMyUserData({ 
          cgmSettings: { 
            ...(user.cgmSettings || {}),
            method: selectedMethod,
            status: 'connected',
            lastTestedAt: new Date().toISOString(),
            lastReading: data.lastReading
          }
        });
        setToastMessage(`Connection successful! Latest reading: ${data.lastReading?.value} mg/dL`);
      } else {
        setConnectionStatus('error');
        await User.updateMyUserData({ cgmSettings: { ...(user.cgmSettings || {}), status: 'error' } });
        setToastMessage(`Connection failed: ${data.error}`);
      }
    } catch (error) {
      setConnectionStatus('error');
      await User.updateMyUserData({ cgmSettings: { ...(user.cgmSettings || {}), status: 'error' } });
      setToastMessage("Connection test failed. Please check your settings.");
    }
    setIsTesting(false);
  };

  const getStatusBadge = () => {
    switch (connectionStatus) {
      case 'connected':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Connected</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800"><AlertCircle className="w-3 h-3 mr-1" />Error</Badge>;
      case 'not_tested':
        return <Badge className="bg-yellow-100 text-yellow-800">Not Tested</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Not Connected</Badge>;
    }
  };

  return (
    <>
      <Toast message={toastMessage} onDismiss={() => setToastMessage('')} />
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">CGM Integration</h1>
            <p className="text-gray-600">Connect your glucose monitoring system for real-time data</p>
            <div className="mt-2">{getStatusBadge()}</div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Choose Your Connection Method</CardTitle>
              <CardDescription>
                Select the best way to connect your glucose data to CarbWise
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={selectedMethod} onValueChange={setSelectedMethod}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="nightscout" className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-500" />
                    Nightscout
                  </TabsTrigger>
                  <TabsTrigger value="dexcom_share" className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4" />
                    Dexcom Share
                  </TabsTrigger>
                  <TabsTrigger value="manual" className="flex items-center gap-2">
                    Manual Entry
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="nightscout" className="space-y-4 mt-6">
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <h4 className="font-medium text-green-900 mb-2 flex items-center gap-2">
                      <Zap className="w-5 h-5 text-green-700"/> The Gold Standard Connection
                    </h4>
                    <p className="text-sm text-green-800 mb-3">
                      Nightscout is the most powerful and reliable way to connect your CGM data to any app. It acts as your personal, secure data hub, giving you full control and a rock-solid connection that avoids the issues with Dexcom Share.
                    </p>
                    <ul className="text-sm text-green-700 space-y-1 mb-3 list-disc list-inside">
                      <li><strong>Works with Dexcom, Libre, & more.</strong></li>
                      <li><strong>Free & open-source.</strong> You own your data.</li>
                      <li><strong>Stable & always on.</strong> No more connection drops.</li>
                    </ul>
                    <Button asChild variant="outline" size="sm" className="bg-white hover:bg-green-100">
                      <a href="https://nightscout.github.io/" target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View the Official Nightscout Setup Guide
                      </a>
                    </Button>
                  </div>
                  
                  <div>
                    <Label htmlFor="nightscout-url">Nightscout URL</Label>
                    <Input 
                      id="nightscout-url"
                      type="url"
                      placeholder="https://yoursitename.herokuapp.com"
                      value={nightscoutUrl}
                      onChange={(e) => setNightscoutUrl(e.target.value)}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Enter your complete Nightscout URL (including https://)
                    </p>
                  </div>
                  
                  <div>
                    <Label htmlFor="nightscout-token">API Token / Secret (Optional)</Label>
                    <Input 
                      id="nightscout-token"
                      type="password"
                      placeholder="Enter API token if your site requires it"
                      value={nightscoutToken}
                      onChange={(e) => setNightscoutToken(e.target.value)}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="dexcom_share" className="space-y-4 mt-6">
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      <p className="font-bold">Not Recommended & Unstable</p>
                      <p>The Dexcom Share connection method frequently fails because Dexcom actively blocks unofficial access. This is outside of our control and may stop working at any time. For a stable and reliable connection, <strong>we strongly recommend using Nightscout.</strong></p>
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="dexcom-username">Dexcom Username (Email)</Label>
                      <Input 
                        id="dexcom-username"
                        type="email"
                        placeholder="your.email@example.com"
                        value={dexcomUsername}
                        onChange={(e) => setDexcomUsername(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="dexcom-password">Dexcom Password</Label>
                      <Input 
                        id="dexcom-password"
                        type="password"
                        placeholder="Enter your Dexcom password"
                        value={dexcomPassword}
                        onChange={(e) => setDexcomPassword(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="dexcom-server">Server Region</Label>
                    <select 
                      id="dexcom-server"
                      className="w-full p-2 border border-gray-300 rounded-md"
                      value={dexcomServer}
                      onChange={(e) => setDexcomServer(e.target.value)}
                    >
                      <option value="us">United States</option>
                      <option value="international">Outside of US</option>
                    </select>
                  </div>
                </TabsContent>

                <TabsContent value="manual" className="space-y-4 mt-6">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-medium text-blue-900 mb-2">✏️ Manual Entry</h4>
                    <p className="text-sm text-blue-700">
                      Manually enter your glucose readings when needed. Great for backup or when other methods aren't available.
                    </p>
                  </div>
                  
                  <div>
                    <Label htmlFor="manual-bg">Current Blood Glucose (mg/dL)</Label>
                    <Input 
                      id="manual-bg"
                      type="number"
                      placeholder="Enter current BG reading"
                      value={manualBG}
                      onChange={(e) => setManualBG(e.target.value)}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      This will be used for insulin calculations
                    </p>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex gap-3 mt-6 pt-6 border-t">
                <Button 
                  onClick={handleSave} 
                  disabled={isSaving}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isSaving ? "Saving..." : "Save Settings"}
                </Button>
                
                {selectedMethod !== 'manual' && (
                  <Button 
                    onClick={handleTestConnection} 
                    disabled={isTesting || isSaving}
                    variant="outline"
                  >
                    {isTesting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {isTesting ? "Testing..." : "Test Connection"}
                  </Button>
                )}
              </div>

              {connectionStatus === 'connected' && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="font-medium text-green-900">Connection Successful!</span>
                  </div>
                  <p className="text-sm text-green-700 mt-1">
                    Your glucose data will now appear in real-time on the Calculator page.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
