
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card'; // Added CardFooter
import { Crown, Star, CheckCircle, Loader2, Heart } from 'lucide-react'; // Changed CheckCircle2, XCircle to CheckCircle
import { createCheckoutSession } from '@/api/functions';
import { manageSubscription } from '@/api/functions';
import { User } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils/navigation';

// Helper function to handle checkout logic, moved outside the component as it's a utility
const handleCheckout = async (targetPlan, setIsLoading, currentUserSubscriptionStatus) => {
  setIsLoading(true);
  try {
    let response;

    // If user is free, create new checkout session.
    // If user is already subscribed but wants a different plan (upgrade/downgrade),
    // we also initiate a checkout session. This assumes `createCheckoutSession`
    // can intelligently handle plan changes for existing subscribers on the backend.
    if (currentUserSubscriptionStatus === 'free' || targetPlan !== currentUserSubscriptionStatus) {
      response = await createCheckoutSession({ plan: targetPlan });
    } else {
      // If the user is already on the targetPlan, they manage their subscription (e.g., update payment, cancel).
      response = await manageSubscription();
    }

    if (response && response.data && response.data.url) {
      window.location.href = response.data.url;
    } else {
      throw new Error('Could not get checkout URL');
    }
  } catch (error) {
    console.error("Subscription Error:", error);
    alert(`Error: ${error.message || 'Something went wrong. Please try again.'}`);
  } finally {
    setIsLoading(false);
  }
};

const PlanCard = ({ plan, onChoosePlan, isLoading, currentPlan }) => {
  const isCurrent = plan.id === currentPlan;
  return (
    <Card className={`flex flex-col ${isCurrent ? 'border-blue-500 ring-2 ring-blue-500' : ''}`}>
      <CardHeader className="text-center">
        <div className="w-16 h-16 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <plan.icon className="w-8 h-8 text-blue-600" />
        </div>
        <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
        <p className="text-gray-600">{plan.description}</p>
      </CardHeader>
      <CardContent className="space-y-6 flex-grow">
        <div className="text-center">
          <span className="text-4xl font-bold">{plan.price}</span>
          <span className="text-gray-500">{plan.price === 'Free' ? '' : '/month'}</span>
        </div>
        <ul className="space-y-3">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        {isCurrent ? (
          <Button disabled className="w-full">Your Current Plan</Button>
        ) : (
          <Button onClick={() => onChoosePlan(plan.id)} disabled={isLoading || plan.id === 'free'} className="w-full">
            {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : ''}
            {plan.price === 'Free' ? 'Included' : `Upgrade to ${plan.name}`}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default function PricingPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState(null); // Stores the full user object

  useEffect(() => {
    User.me().then(setUser).catch(() => setUser(null));
  }, []);

  const handleChoosePlan = async (planId) => {
    if (planId === 'free') return; // Free plan doesn't require a checkout session
    // Pass the user's current subscription status to the helper function
    await handleCheckout(planId, setIsLoading, user?.subscriptionStatus);
  };

  const plans = [
    {
      id: "free",
      name: "Free",
      price: "Free",
      description: "Essential tools for everyday management.",
      icon: Heart,
      features: [
        "3 Restaurant Picks",
        "Manual Food Entry",
        "Live CGM Connection",
        "Basic High/Low BG Alerts",
        "Insulin Dose Calculator",
        "Meal History (7 days)"
      ],
    },
    {
      id: "premium",
      name: "Premium",
      price: "$4.99",
      description: "For users who want more tracking power.",
      icon: Crown,
      features: [
        "All Free features, plus:",
        "6 Restaurant Picks", // Changed from "10 Restaurant Picks"
        "Smart Menu Importer",
        "Full Meal History & Analytics",
        "Export Meal Data",
        "Priority Support",
      ],
    },
    {
      id: "premium_plus",
      name: "Premium Plus",
      price: "$9.99",
      description: "The ultimate AI-powered diabetes toolkit.",
      icon: Star,
      features: [
        "All Premium features, plus:",
        "Unlimited Restaurant Access",
        "AI-Powered Glucose Analysis",
        "AI-Powered Smart Alerts (Rapid Rise/Fall)",
        "Predictive Health Insights",
        "Early Access to New Features",
      ],
    },
  ];

  // Determine the current plan from user state
  const currentUserPlan = user?.subscriptionStatus || 'free';

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <header className="flex justify-between items-center mb-12">
          <Link to={createPageUrl("Home")} className="flex items-center gap-2">
            <Heart className="w-7 h-7 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">CarbWise</span>
          </Link>
          <Button asChild variant="outline">
            <Link to={createPageUrl("Calculator")}>
              Back to App
            </Link>
          </Button>
        </header>

        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900">Find the Perfect Plan</h1>
          <p className="mt-4 text-lg text-gray-600">Take control of your diabetes management with the right tools.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 items-stretch"> {/* Use items-stretch for equal height cards */}
          {plans.map((plan) => (
            <PlanCard
              key={plan.id}
              plan={plan}
              onChoosePlan={handleChoosePlan}
              isLoading={isLoading}
              currentPlan={currentUserPlan}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
