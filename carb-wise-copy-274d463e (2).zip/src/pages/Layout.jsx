
import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Calculator, History, Home, Heart, Settings, UploadCloud, Crown, Rss } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import LoginButton from "./components/auth/LoginButton";

const navigationItems = [
  {
    title: "Calculator",
    url: createPageUrl("Calculator"),
    icon: Calculator,
  },
  {
    title: "Meal History",
    url: createPageUrl("MealHistory"),
    icon: History,
  },
  {
    title: "My Settings",
    url: createPageUrl("Settings"),
    icon: Settings,
  },
  {
    title: "CGM Setup",
    url: createPageUrl("CGMSettings"),
    icon: Heart,
  },
  {
    title: "Import Menu",
    url: createPageUrl("MenuImporter"),
    icon: UploadCloud,
    premium: true
  },
  {
    title: "Live Menu",
    url: createPageUrl("LiveMenu"),
    icon: Rss,
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (currentPageName) {
      const title = currentPageName.replace(/([A-Z])/g, ' $1').trim();
      document.title = `${title} | CarbWise`;
    } else {
      document.title = 'CarbWise - Smart Diabetes Management';
    }
    
    // Add PWA meta tags
    const addMetaTag = (name, content) => {
      let meta = document.querySelector(`meta[name="${name}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.name = name;
        document.head.appendChild(meta);
      }
      meta.content = content;
    };

    // PWA Configuration for Google Play Store
    addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover');
    addMetaTag('theme-color', '#2563EB');
    addMetaTag('apple-mobile-web-app-capable', 'yes');
    addMetaTag('apple-mobile-web-app-status-bar-style', 'default');
    addMetaTag('apple-mobile-web-app-title', 'CarbWise');
    addMetaTag('application-name', 'CarbWise');
    addMetaTag('mobile-web-app-capable', 'yes');
    addMetaTag('description', 'AI-powered diabetes management with real-time glucose monitoring and smart carb tracking');
    
    // Create and inject manifest JSON
    const manifestContent = {
      "name": "CarbWise - Smart Diabetes Management",
      "short_name": "CarbWise",
      "description": "AI-powered diabetes management with real-time glucose monitoring and smart carb tracking",
      "start_url": "/",
      "display": "standalone",
      "background_color": "#ffffff",
      "theme_color": "#2563EB",
      "orientation": "portrait-primary",
      "categories": ["health", "medical", "lifestyle"],
      "icons": [
        {
          "src": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'%3E%3Ccircle fill='%232563EB' cx='96' cy='96' r='96'/%3E%3Cpath fill='%23ffffff' d='M96 40c-8 0-14 6-14 14v28H54c-8 0-14 6-14 14s6 14 14 14h28v28c0 8 6 14 14 14s14-6 14-14v-28h28c8 0 14-6 14-14s-6-14-14-14h-28V54c0-8-6-14-14-14z'/%3E%3C/svg%3E",
          "sizes": "192x192",
          "type": "image/svg+xml",
          "purpose": "any maskable"
        },
        {
          "src": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'%3E%3Ccircle fill='%232563EB' cx='256' cy='256' r='256'/%3E%3Cpath fill='%23ffffff' d='M256 100c-20 0-36 16-36 36v84H136c-20 0-36 16-36 36s16 36 36 36h84v84c0 20 16 36 36 36s36-16 36-36v-84h84c20 0 36-16 36-36s-16-36-36-36h-84v-84c0-20-16-36-36-36z'/%3E%3C/svg%3E",
          "sizes": "512x512",
          "type": "image/svg+xml",
          "purpose": "any maskable"
        }
      ],
      "shortcuts": [
        {
          "name": "Calculate Carbs",
          "short_name": "Calculator",
          "description": "Quick access to carb calculator",
          "url": "/Calculator",
          "icons": [
            {
              "src": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'%3E%3Ccircle fill='%232563EB' cx='48' cy='48' r='48'/%3E%3C/svg%3E",
              "sizes": "96x96"
            }
          ]
        }
      ]
    };

    // Add manifest link
    if (!document.querySelector('link[rel="manifest"]')) {
      const manifestBlob = new Blob([JSON.stringify(manifestContent)], { type: 'application/json' });
      const manifestURL = URL.createObjectURL(manifestBlob);
      const manifestLink = document.createElement('link');
      manifestLink.rel = 'manifest';
      manifestLink.href = manifestURL;
      document.head.appendChild(manifestLink);
    }

    // Register Service Worker for offline capability
    if ('serviceWorker' in navigator) {
      const swCode = `
        const CACHE_NAME = 'carbwise-v1';
        const urlsToCache = [
          '/', 
          '/Calculator', 
          '/MealHistory', 
          '/Settings', 
          '/CGMSettings', 
          '/Pricing', 
          '/MenuImporter',
          '/LiveMenu'
        ];

        self.addEventListener('install', event => {
          self.skipWaiting();
          event.waitUntil(
            caches.open(CACHE_NAME)
              .then(cache => cache.addAll(urlsToCache))
              .catch(console.error)
          );
        });

        self.addEventListener('fetch', event => {
          if (!event.request.url.startsWith(self.location.origin)) return;
          
          event.respondWith(
            caches.match(event.request)
              .then(response => response || fetch(event.request))
              .catch(() => caches.match('/'))
          );
        });

        self.addEventListener('activate', event => {
          event.waitUntil(
            caches.keys().then(cacheNames => 
              Promise.all(
                cacheNames.map(cacheName => 
                  cacheName !== CACHE_NAME ? caches.delete(cacheName) : null
                )
              )
            )
          );
        });
      `;

      const swBlob = new Blob([swCode], { type: 'application/javascript' });
      const swURL = URL.createObjectURL(swBlob);
      
      navigator.serviceWorker.register(swURL)
        .then(registration => console.log('SW registered:', registration))
        .catch(error => console.log('SW registration failed:', error));
    }
  }, [currentPageName]);

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-blue-50 to-white">
        <Sidebar className="border-r border-blue-100">
          <SidebarHeader className="border-b border-blue-100 p-6">
            <Link to={createPageUrl("Calculator")} className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900 text-lg">CarbWise</h2>
                <p className="text-sm text-blue-600 font-medium">Smart Diabetes Management</p>
              </div>
            </Link>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2 py-3">
                Navigation
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-lg mb-2 ${
                          location.pathname === item.url ? 'bg-gradient-to-r from-blue-100 to-blue-50 text-blue-700 font-medium shadow-sm' : ''
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                          {item.premium && (
                            <Crown className="w-4 h-4 text-yellow-600 ml-auto" />
                          )}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-8">
              <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2 py-3">
                Health Tips
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <div className="px-4 py-3 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg border border-blue-100">
                  <p className="text-sm text-blue-700 font-medium mb-2">💡 Daily Tip</p>
                  <p className="text-xs text-blue-600 leading-relaxed">
                    Consistent carb counting helps improve your glucose management. Keep tracking daily!
                  </p>
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
            
            {/* Add Login/Logout at bottom of sidebar */}
            <SidebarGroup className="mt-auto">
              <SidebarGroupContent>
                <div className="px-4 py-3">
                  <LoginButton onUserChange={setUser} />
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 px-6 py-4 md:hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-blue-50 p-2 rounded-lg transition-colors duration-200" />
                <h1 className="text-xl font-bold text-gray-900">CarbWise</h1>
              </div>
              <div className="md:hidden">
                <LoginButton onUserChange={setUser} />
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
