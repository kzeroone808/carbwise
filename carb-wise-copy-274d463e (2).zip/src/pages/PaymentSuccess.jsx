import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { CheckCircle, PartyPopper } from 'lucide-react';
import { User } from '@/api/entities';
import { verifySubscription } from '@/api/functions';

export default function PaymentSuccessPage() {
  const [status, setStatus] = useState('verifying');
  const [user, setUser] = useState(null);

  useEffect(() => {
    const verify = async () => {
      try {
        const { data } = await verifySubscription();
        if (data && data.success) {
          const userData = await User.me();
          setUser(userData);
          setStatus('success');
        } else {
          setStatus('failed');
        }
      } catch (error) {
        setStatus('failed');
      }
    };
    verify();
  }, []);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white p-8 md:p-12 rounded-2xl shadow-lg text-center max-w-lg w-full">
        {status === 'success' && (
          <>
            <PartyPopper className="w-20 h-20 text-green-500 mx-auto mb-6" />
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Payment Successful!</h1>
            <p className="text-gray-600 mb-8">
              Thank you for upgrading! Your new <span className="font-semibold text-purple-600 capitalize">{user?.subscriptionStatus?.replace('_', ' ')}</span> features are now active.
            </p>
            <Button asChild size="lg" className="w-full">
              <Link to={createPageUrl("Calculator")}>Start Using Premium Features</Link>
            </Button>
          </>
        )}
        
        {status === 'verifying' && (
          <>
            <CheckCircle className="w-20 h-20 text-blue-500 mx-auto mb-6 animate-pulse" />
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Verifying Your Purchase...</h1>
            <p className="text-gray-600 mb-8">
              Please wait while we confirm your subscription and unlock your new features.
            </p>
          </>
        )}

        {status === 'failed' && (
          <>
            <h1 className="text-3xl font-bold text-red-600 mb-4">Verification Failed</h1>
            <p className="text-gray-600 mb-8">
              There was an issue verifying your subscription status. Please check your account in a few moments or contact support if the problem persists.
            </p>
             <Button asChild size="lg" className="w-full">
              <Link to={createPageUrl("Index")}>Back to Home</Link>
            </Button>
          </>
        )}
      </div>
    </div>
  );
}