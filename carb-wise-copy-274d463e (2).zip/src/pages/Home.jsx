import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { Zap, Brain, BarChart3, ShieldCheck, Heart, ArrowRight } from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, description }) => (
  <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
    <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full mb-4">
      <Icon className="w-6 h-6 text-blue-600" />
    </div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const TestimonialCard = ({ quote, name, condition }) => (
  <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
    <p className="text-gray-700 italic">"{quote}"</p>
    <p className="font-semibold text-blue-800 mt-4">- {name}</p>
    <p className="text-sm text-blue-600">{condition}</p>
  </div>
);

export default function HomePage() {
  return (
    <div className="bg-white text-gray-800">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-sm z-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Heart className="w-8 h-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">CarbWise</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-600 hover:text-blue-600">Features</a>
              <a href="#pricing" className="text-gray-600 hover:text-blue-600">Pricing</a>
            </div>
            <Button asChild>
              <Link to={createPageUrl("Calculator")}>Open App</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative text-center py-20 md:py-32 px-4 bg-gradient-to-br from-blue-50 to-white">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 leading-tight">
              Smarter Diabetes Management Starts Here.
            </h1>
            <p className="mt-6 text-lg md:text-xl text-gray-600 max-w-2xl mx-auto">
              CarbWise empowers you to track meals, monitor glucose, and make informed decisions with powerful, AI-driven insights. Take control with confidence.
            </p>
            <div className="mt-8 flex justify-center gap-4">
              <Button asChild size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg">
                <Link to={createPageUrl("Calculator")}>
                  Get Started for Free
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
            </div>
          </div>
          <div className="mt-12">
            <img 
              src="https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
              alt="Healthy Meal"
              className="w-full max-w-4xl mx-auto rounded-xl shadow-2xl object-cover h-96"
            />
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20 px-4 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Everything You Need for Better Control</h2>
              <p className="mt-4 text-lg text-gray-600">CarbWise is packed with features designed by and for people with diabetes.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <FeatureCard 
                icon={Zap}
                title="Live CGM Integration"
                description="Connect your Dexcom or Nightscout to see real-time glucose data and trends directly in the app."
              />
              <FeatureCard 
                icon={Brain}
                title="AI-Powered Insights"
                description="Get smart alerts for rapid BG changes and predictive analysis to prevent highs and lows before they happen."
              />
              <FeatureCard 
                icon={BarChart3}
                title="Advanced Analytics"
                description="Track your meal history, see your time-in-range, and understand how food impacts your glucose levels."
              />
              <FeatureCard 
                icon={ShieldCheck}
                title="Accurate Carb Database"
                description="Access nutritional data for thousands of restaurant items or import any menu with our Smart Importer."
              />
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 px-4 bg-white">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Trusted by Diabetics Like You</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <TestimonialCard 
                quote="CarbWise has been a game-changer. The AI alerts have helped me catch lows before they become serious. I feel so much more in control."
                name="Sarah J."
                condition="Type 1 Diabetic since 2015"
              />
              <TestimonialCard 
                quote="As someone newly diagnosed, this app took away so much anxiety. The carb calculator is incredibly easy to use when I'm eating out."
                name="Michael B."
                condition="Type 2 Diabetic"
              />
            </div>
          </div>
        </section>
        
        {/* Pricing CTA */}
        <section id="pricing" className="py-20 px-4 bg-gray-50">
            <div className="max-w-4xl mx-auto text-center bg-gradient-to-r from-blue-600 to-purple-600 text-white p-12 rounded-xl shadow-lg">
                <h2 className="text-3xl font-bold">Find the Perfect Plan</h2>
                <p className="mt-4 text-lg text-blue-100">
                    From essential tracking to advanced AI insights, CarbWise has a plan that fits your life.
                </p>
                <Button asChild size="lg" variant="secondary" className="mt-8 bg-white text-blue-600 hover:bg-blue-50">
                    <Link to={createPageUrl("Pricing")}>View Pricing & Plans</Link>
                </Button>
            </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8 text-center">
            <p>© 2024 CarbWise. All rights reserved.</p>
            <p className="text-sm text-gray-400 mt-2">This tool is not a medical device. Consult your doctor for medical advice.</p>
        </div>
      </footer>
    </div>
  );
}