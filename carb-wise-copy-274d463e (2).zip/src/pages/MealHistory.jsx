
import React, { useState, useEffect } from "react";
import { Meal } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Target, Utensils, Zap } from "lucide-react";
import { format } from "date-fns";

export default function MealHistory() {
  const [meals, setMeals] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadMeals();
  }, []);

  const loadMeals = async () => {
    try {
      const data = await Meal.list("-meal_date");
      setMeals(data);
    } catch (error) {
      console.error("Error loading meals:", error);
    }
    setIsLoading(false);
  };

  const getWeeklyAverage = () => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    const recentMeals = meals.filter(meal => new Date(meal.meal_date) >= weekAgo);
    const totalCarbs = recentMeals.reduce((sum, meal) => sum + meal.total_carbs, 0);
    
    return recentMeals.length > 0 ? (totalCarbs / recentMeals.length).toFixed(1) : 0;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid md:grid-cols-3 gap-4">
              {Array(3).fill(0).map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
              <Clock className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Meal History</h1>
              <p className="text-gray-600">Track your carbohydrate intake over time</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-8">
            <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Target className="w-8 h-8 text-blue-600" />
                  <div>
                    <p className="text-sm text-blue-600 font-medium">Total Meals</p>
                    <p className="text-2xl font-bold text-blue-700">{meals.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-green-200 bg-gradient-to-br from-green-50 to-green-100">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Calendar className="w-8 h-8 text-green-600" />
                  <div>
                    <p className="text-sm text-green-600 font-medium">Weekly Average</p>
                    <p className="text-2xl font-bold text-green-700">{getWeeklyAverage()}g</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Utensils className="w-8 h-8 text-purple-600" />
                  <div>
                    <p className="text-sm text-purple-600 font-medium">Last Meal</p>
                    <p className="text-lg font-bold text-purple-700">
                      {meals[0] ? `${meals[0].total_carbs}g` : 'None'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {meals.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Clock className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No meals recorded yet</h3>
              <p className="text-gray-500">Start tracking your meals with the CarbWise Calculator</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {meals.map((meal) => (
              <Card key={meal.id} className="hover:shadow-md transition-shadow duration-200">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <CardTitle className="text-lg font-semibold">{meal.name}</CardTitle>
                    <div className="flex items-center gap-2 text-sm text-500">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(meal.meal_date), "MMM d, yyyy")}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge variant="outline" className="bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 border-blue-200 capitalize">
                          {meal.restaurant?.replace(/_/g, ' ')}
                        </Badge>
                        <Badge variant="outline" className="bg-gradient-to-r from-green-50 to-green-100 text-green-700 border-green-200">
                          {meal.total_carbs}g carbs
                        </Badge>
                        <Badge variant="outline" className="bg-gradient-to-r from-orange-50 to-orange-100 text-orange-700 border-orange-200">
                          {meal.total_calories} calories
                        </Badge>
                        {meal.suggested_bolus && (
                            <Badge variant="outline" className="bg-gradient-to-r from-purple-50 to-purple-100 text-purple-700 border-purple-200">
                                <Zap className="w-3 h-3 mr-1" />
                                {meal.suggested_bolus.toFixed(2)} units
                            </Badge>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium text-gray-900 text-sm">Items:</h4>
                        <div className="grid gap-2">
                          {meal.items?.map((item, index) => (
                            <div key={index} className="flex justify-between items-center text-sm bg-gray-50 p-2 rounded">
                              <span className="text-gray-700">
                                {item.quantity}x {item.food_name} ({item.size})
                              </span>
                              <span className="font-medium text-blue-600">
                                {item.carbs * item.quantity}g carbs
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
