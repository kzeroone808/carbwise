
import React, { useState, useEffect } from 'react';
import { UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { FoodItem, User } from "@/api/entities";
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UploadCloud, FileText, Loader2, CheckCircle, AlertTriangle, Crown, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function MenuImporter() {
  const [file, setFile] = useState(null);
  const [restaurantName, setRestaurantName] = useState('');
  const [status, setStatus] = useState('idle');
  const [message, setMessage] = useState('');
  const [importedCount, setImportedCount] = useState(0);
  const [userTier, setUserTier] = useState('free');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const user = await User.me();
      if (user) {
        setUserTier(user.subscriptionStatus || 'free');
      }
    } catch (error) {
      console.log("User not logged in");
    }
    setIsLoading(false);
  };

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setFile(e.target.files[0]);
      setStatus('idle');
      setMessage('');
    }
  };

  const handleImport = async () => {
    if (userTier === 'free') {
      setMessage("This feature requires a Premium or Premium Plus subscription.");
      return;
    }

    if (!file || !restaurantName) {
      setMessage("Please provide a restaurant name and a menu file.");
      return;
    }

    setStatus('uploading');
    setMessage('Uploading menu file...');
    try {
      const { file_url } = await UploadFile({ file });

      setStatus('processing');
      setMessage('AI is reading the menu... this may take a moment.');

      const foodItemSchema = {
        type: 'object',
        properties: {
          items: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                category: { type: 'string' },
                sizes: {
                  type: 'object',
                  properties: {
                    small: { type: 'object', properties: { carbs: { type: 'number' }, calories: { type: 'number' } } },
                    medium: { type: 'object', properties: { carbs: { type: 'number' }, calories: { type: 'number' } } },
                    large: { type: 'object', properties: { carbs: { type: 'number' }, calories: { type: 'number' } } },
                  }
                }
              },
              required: ['name', 'sizes']
            }
          }
        }
      };
      
      const extractionResult = await ExtractDataFromUploadedFile({
        file_url: file_url,
        json_schema: foodItemSchema,
      });

      if (extractionResult.status === 'success' && extractionResult.output.items) {
        const itemsToCreate = extractionResult.output.items.map(item => ({
          ...item,
          restaurant: restaurantName.toLowerCase().replace(/\s+/g, '_'),
          category: item.category || 'imported',
          is_custom: true,
        }));
        
        await FoodItem.bulkCreate(itemsToCreate);
        setImportedCount(itemsToCreate.length);
        setStatus('success');
        setMessage(`Successfully imported ${itemsToCreate.length} items from ${restaurantName}!`);
        setFile(null);
        setRestaurantName('');
      } else {
        throw new Error(extractionResult.details || 'Could not extract data from the menu.');
      }

    } catch (err) {
      setStatus('error');
      setMessage(`Import failed: ${err.message}`);
      console.error(err);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  // Show premium gate for free users
  if (userTier === 'free') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
              <UploadCloud className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Smart Menu Importer</h1>
              <p className="text-gray-600">Upload any menu. Let AI do the work.</p>
            </div>
          </div>
          
          <Card className="border-2 border-dashed border-gray-300 bg-gray-50">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Crown className="w-10 h-10 text-white" />
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Premium Feature</h2>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                The Smart Menu Importer uses advanced AI to extract carb data from any restaurant menu. 
                This powerful feature is available to Premium and Premium Plus subscribers.
              </p>
              
              <div className="grid md:grid-cols-2 gap-4 mb-8">
                <Card className="border-yellow-200 bg-gradient-to-br from-yellow-50 to-yellow-100">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Crown className="w-6 h-6 text-yellow-600" />
                      <h3 className="font-bold text-yellow-900">Premium</h3>
                    </div>
                    <p className="text-sm text-yellow-800 mb-4">Perfect for regular users</p>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-900">$4.99</div>
                      <div className="text-sm text-yellow-700">per month</div>
                    </div>
                    <ul className="text-sm text-yellow-800 mt-4 space-y-1">
                      <li>• 6 Restaurant Picks</li>
                      <li>• Smart Menu Importer</li>
                      <li>• Advanced Calculations</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Crown className="w-6 h-6 text-purple-600" />
                      <h3 className="font-bold text-purple-900">Premium Plus</h3>
                    </div>
                    <p className="text-sm text-purple-800 mb-4">For power users</p>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-900">$9.99</div>
                      <div className="text-sm text-purple-700">per month</div>
                    </div>
                    <ul className="text-sm text-purple-800 mt-4 space-y-1">
                      <li>• Unlimited Restaurants</li>
                      <li>• Unlimited AI Imports</li>
                      <li>• Advanced AI Analysis</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <div className="space-y-4">
                <Button 
                  onClick={() => window.location.href = createPageUrl('Pricing')}
                  className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white px-8 py-3"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Premium
                </Button>
                
                <div>
                  <Button asChild variant="outline">
                    <Link to={createPageUrl('Calculator')}>
                      ← Back to Calculator
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Show full importer for premium users
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
            <UploadCloud className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Smart Menu Importer</h1>
            <p className="text-gray-600">Upload any menu. Let AI do the work.</p>
          </div>
          <div className="ml-auto">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-yellow-600" />
              <span className="text-sm font-medium text-yellow-700 capitalize">
                {userTier.replace('_', ' ')} Feature
              </span>
            </div>
          </div>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Import a New Menu</CardTitle>
            <CardDescription>
              Provide a restaurant name and its menu file (PDF, TXT, or image). 
              Our AI will automatically extract all the carb information for you.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="restaurant-name">Restaurant Name</Label>
              <Input
                id="restaurant-name"
                value={restaurantName}
                onChange={(e) => setRestaurantName(e.target.value)}
                placeholder="e.g., The Local Pizzeria"
                disabled={status === 'processing' || status === 'uploading'}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="file-upload">Menu File</Label>
              <div className="flex items-center justify-center w-full">
                  <label htmlFor="file-upload" className="flex flex-col items-center justify-center w-full h-48 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <UploadCloud className="w-10 h-10 mb-3 text-gray-400" />
                          {file ? (
                            <>
                              <p className="mb-2 text-sm text-gray-500 font-semibold">{file.name}</p>
                              <p className="text-xs text-gray-500">Click to change file</p>
                            </>
                          ) : (
                            <>
                              <p className="mb-2 text-sm text-gray-500"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                              <p className="text-xs text-gray-500">PDF, TXT, PNG, JPG</p>
                            </>
                          )}
                      </div>
                      <Input id="file-upload" type="file" className="hidden" onChange={handleFileChange} accept=".pdf,.txt,.png,.jpg,.jpeg" />
                  </label>
              </div>
            </div>

            <Button 
              onClick={handleImport} 
              disabled={!file || !restaurantName || status === 'processing' || status === 'uploading'} 
              className="w-full"
            >
              {status === 'idle' && 'Import Menu with AI'}
              {status === 'uploading' && <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Uploading...</>}
              {status === 'processing' && <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> AI Processing...</>}
              {(status === 'success' || status === 'error') && 'Import Another Menu'}
            </Button>

            {message && (
              <div className={`flex items-center p-4 rounded-md ${
                status === 'success' ? 'bg-green-50 text-green-800' :
                status === 'error' ? 'bg-red-50 text-red-800' :
                'bg-blue-50 text-blue-800'
              }`}>
                {status === 'success' && <CheckCircle className="h-5 w-5 mr-3" />}
                {status === 'error' && <AlertTriangle className="h-5 w-5 mr-3" />}
                {status !== 'success' && status !== 'error' && <Loader2 className="h-5 w-5 mr-3 animate-spin" />}
                <p className="text-sm font-medium">{message}</p>
              </div>
            )}
            
            {status === 'success' && (
              <Card className="text-center p-4 bg-green-50 border-green-200">
                  <CardDescription className="text-green-800">
                    🎉 Your new items are now available in the calculator. You can filter by the "My Items" category to see them.
                  </CardDescription>
                   <Button asChild variant="link" className="mt-2 text-green-700">
                       <Link to={createPageUrl('Calculator')}>Go to Calculator</Link>
                   </Button>
              </Card>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
