import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, LinkIcon, Rss, AlertTriangle } from 'lucide-react';
import { scrapeNutrislice } from '@/api/functions';

export default function LiveMenu() {
    const [url, setUrl] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [menuData, setMenuData] = useState(null);
    const [error, setError] = useState('');

    const handleScrape = async () => {
        if (!url) {
            setError('Please enter a valid Nutrislice URL.');
            return;
        }
        setIsLoading(true);
        setError('');
        setMenuData(null);
        try {
            const { data, error: apiError } = await scrapeNutrislice({ menuUrl: url });
            if (apiError || !data) {
                throw new Error(apiError?.error || 'Failed to scrape menu. The URL might be incorrect or the menu is not available.');
            }
            setMenuData(data);
        } catch (err) {
            setError(err.message);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4 md:p-8">
            <div className="max-w-4xl mx-auto">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-cyan-600 rounded-xl flex items-center justify-center">
                        <Rss className="w-7 h-7 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Live Menu Importer</h1>
                        <p className="text-gray-600">Paste a Nutrislice URL to fetch the real-time menu.</p>
                    </div>
                </div>

                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle>Enter Menu URL</CardTitle>
                        <CardDescription>
                            Find your school's menu on the Nutrislice website and paste the full URL below to import it.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col md:flex-row gap-4">
                        <div className="relative flex-grow">
                            <LinkIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                            <Input 
                                id="url" 
                                placeholder="https://yourschool.nutrislice.com/menu/your-school/lunch" 
                                value={url} 
                                onChange={e => setUrl(e.target.value)} 
                                className="pl-10"
                            />
                        </div>
                        <Button onClick={handleScrape} disabled={isLoading}>
                            {isLoading ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Fetching Menu...
                                </>
                            ) : 'Fetch Menu'}
                        </Button>
                    </CardContent>
                </Card>

                {error && (
                    <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-8" role="alert">
                        <div className="flex">
                            <div className="py-1"><AlertTriangle className="h-6 w-6 text-red-500 mr-4" /></div>
                            <div>
                                <p className="font-bold">Import Error</p>
                                <p className="text-sm">{error}</p>
                            </div>
                        </div>
                    </div>
                )}
                
                {menuData && (
                    <div>
                        <h2 className="text-2xl font-bold text-gray-800 mb-4">{menuData.menuTitle}</h2>
                        <div className="space-y-6">
                            {menuData.days.map((day, dayIndex) => (
                                <Card key={dayIndex}>
                                    <CardHeader>
                                        <CardTitle>{day.date}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        {day.meals.map((meal, mealIndex) => (
                                            <div key={mealIndex}>
                                                <h4 className="font-semibold text-lg text-gray-700 mb-2">{meal.name}</h4>
                                                <ul className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                                    {meal.items.map((item, itemIndex) => (
                                                        <li key={itemIndex} className="bg-gray-50 p-3 rounded-lg">
                                                            <p className="font-medium text-sm text-gray-900">{item.name}</p>
                                                            <p className="text-xs text-gray-500">{item.category}</p>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        ))}
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}