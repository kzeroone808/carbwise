import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Flame, Target, TrendingUp } from "lucide-react";

export default function StreakCounter({ streak, totalMeals }) {
  const getStreakBadge = (streak) => {
    if (streak >= 30) return { icon: "🏆", text: "Champion", color: "bg-yellow-500" };
    if (streak >= 14) return { icon: "🔥", text: "On Fire", color: "bg-red-500" };
    if (streak >= 7) return { icon: "⭐", text: "Rising", color: "bg-blue-500" };
    if (streak >= 3) return { icon: "🌱", text: "Growing", color: "bg-green-500" };
    return { icon: "💪", text: "Getting Started", color: "bg-gray-500" };
  };

  const badge = getStreakBadge(streak);

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <Flame className="w-5 h-5 text-orange-500" />
              <span className="text-2xl font-bold text-gray-900">{streak}</span>
              <span className="text-sm text-gray-600">day streak</span>
            </div>
            <Badge className={`${badge.color} text-white`}>
              {badge.icon} {badge.text}
            </Badge>
          </div>
          
          <div className="text-right">
            <div className="flex items-center gap-1 text-sm text-gray-600">
              <Target className="w-4 h-4" />
              <span>{totalMeals} meals logged</span>
            </div>
          </div>
        </div>
        
        {streak > 0 && (
          <div className="mt-3 text-sm text-blue-700 bg-blue-100 p-2 rounded-lg">
            <TrendingUp className="w-4 h-4 inline mr-1" />
            Great job staying consistent! Keep logging your meals daily.
          </div>
        )}
      </CardContent>
    </Card>
  );
}