import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function LoginButton({ onUserChange }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      onUserChange?.(currentUser);
    } catch (error) {
      setUser(null);
      onUserChange?.(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async () => {
    try {
      await User.login();
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await User.logout();
      setUser(null);
      onUserChange?.(null);
      window.location.reload();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (isLoading) {
    return (
      <Button variant="ghost" disabled>
        <UserIcon className="w-4 h-4 mr-2" />
        Loading...
      </Button>
    );
  }

  if (user) {
    return (
      <div className="flex items-center gap-3">
        <div className="text-sm text-gray-600">
          Welcome, {user.full_name || user.email}
        </div>
        <Button onClick={handleLogout} variant="ghost" size="sm">
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </Button>
      </div>
    );
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardContent className="p-6 text-center">
        <h3 className="text-xl font-bold mb-2">Sign In Required</h3>
        <p className="text-gray-600 mb-4">Please sign in to access CarbWise</p>
        <Button onClick={handleLogin} className="w-full">
          <LogIn className="w-4 h-4 mr-2" />
          Sign In with Google
        </Button>
      </CardContent>
    </Card>
  );
}