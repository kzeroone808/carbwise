import React from "react";
import { Button } from "@/components/ui/button";

const categories = [
  { id: "all", name: "All Items", icon: "🍽️" },
  { id: "burgers", name: "Burgers", icon: "🍔" },
  { id: "chicken", name: "Chicken", icon: "🍗" },
  { id: "sandwiches", name: "Sandwiches", icon: "🥪" },
  { id: "pizza", name: "Pizza", icon: "🍕" },
  { id: "bowls", name: "Bowls", icon: "🥣" },
  { id: "mexican", name: "Mexican", icon: "🌮" },
  { id: "wings", name: "Wings", icon: "🍗" },
  { id: "seafood", name: "Seafood", icon: "🦞" },
  { id: "steaks", name: "Steaks", icon: "🥩" },
  { id: "pasta", name: "Pasta", icon: "🍝" },
  { id: "salads", name: "Salads", icon: "🥗" },
  { id: "sides", name: "Sides", icon: "🍟" },
  { id: "breakfast", name: "Breakfast", icon: "🥞" },
  { id: "desserts", name: "Desserts", icon: "🍰" },
  { id: "beverages", name: "Beverages", icon: "🥤" },
  { id: "coffee", name: "Coffee", icon: "☕" },
  { id: "custom", name: "My Items", icon: "⭐" }
];

export default function CategoryFilter({ selectedCategory, onSelectCategory }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2">
      {categories.map((category) => (
        <Button
          key={category.id}
          variant={selectedCategory === category.id ? "default" : "outline"}
          size="sm"
          onClick={() => onSelectCategory(category.id)}
          className={`whitespace-nowrap transition-all duration-200 ${
            selectedCategory === category.id
              ? 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg scale-105'
              : 'hover:bg-blue-50 hover:text-blue-700 hover:scale-105'
          }`}
        >
          <span className="mr-2">{category.icon}</span>
          {category.name}
        </Button>
      ))}
    </div>
  );
}