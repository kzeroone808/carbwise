
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { AlertTriangle, HelpCircle, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function BolusCalculator({ open, onOpenChange, totalCarbs, onSave, latestBG, userTier = "free" }) {
  const [settings, setSettings] = useState(null);
  const [currentBG, setCurrentBG] = useState('');
  const [calculation, setCalculation] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (open) {
      const loadUserSettings = async () => {
        setIsLoading(true);
        setCalculation(null);
        try {
          const user = await User.me();
          if (user && user.insulinToCarbRatio && user.insulinSensitivityFactor && user.targetBloodGlucose) {
            setSettings({
              icr: user.insulinToCarbRatio,
              isf: user.insulinSensitivityFactor,
              target: user.targetBloodGlucose,
            });
          } else {
            setSettings(null);
          }
        } catch (error) {
          console.error("Failed to load user settings:", error);
          setSettings(null);
        }
        setIsLoading(false);
      };
      loadUserSettings();
      
      // Auto-fill BG regardless of user tier as per new feature
      if (latestBG) {
        setCurrentBG(latestBG.toString());
      } else {
        setCurrentBG('');
      }
    }
  }, [open, latestBG]); // Removed userTier from dependency array as it's no longer a condition for auto-fill

  useEffect(() => {
    if (settings && currentBG) {
      const bg = parseFloat(currentBG);
      const carbBolus = totalCarbs / settings.icr;
      let correctionBolus = 0;
      if (bg > settings.target) {
        correctionBolus = (bg - settings.target) / settings.isf;
      }
      
      const totalBolus = carbBolus + correctionBolus;

      setCalculation({
        carbBolus: carbBolus.toFixed(2),
        correctionBolus: correctionBolus.toFixed(2),
        totalBolus: totalBolus.toFixed(2),
      });
    } else {
      setCalculation(null);
    }
  }, [currentBG, settings, totalCarbs]);
  
  const handleSaveAndClose = () => {
    onSave(calculation ? Number(calculation.totalBolus) : null);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Insulin Dose Suggestion
          </DialogTitle>
          <DialogDescription>
            Enter your current blood glucose to get a dose estimate.
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex justify-center items-center h-40"><Loader2 className="w-8 h-8 animate-spin" /></div>
        ) : !settings ? (
          <div className="text-center py-6">
            <HelpCircle className="mx-auto w-12 h-12 text-blue-500 mb-4" />
            <p className="font-semibold mb-2">Dosing settings not found.</p>
            <p className="text-sm text-gray-600 mb-4">Please configure your personal ratios in the settings page to use this feature.</p>
            <Button asChild>
              <Link to={createPageUrl("Settings")} onClick={() => onOpenChange(false)}>Go to Settings</Link>
            </Button>
          </div>
        ) : (
          <div className="py-4 space-y-4">
            <div className="grid grid-cols-2 gap-4 items-end">
              <div>
                <Label htmlFor="total-carbs">Total Carbs (g)</Label>
                <Input id="total-carbs" value={totalCarbs} disabled className="font-bold text-lg" />
              </div>
              <div>
                <Label htmlFor="current-bg">
                  Current BG (mg/dL)
                </Label>
                <Input 
                  id="current-bg" 
                  type="number" 
                  value={currentBG} 
                  onChange={(e) => setCurrentBG(e.target.value)} 
                  placeholder="e.g., 120"
                />
                {latestBG && ( // Display auto-fill message if BG was available
                  <p className="text-xs text-gray-500 mt-1">
                    Auto-filled from your CGM.
                  </p>
                )}
              </div>
            </div>

            {calculation && (
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Carb Coverage:</span>
                  <span className="font-medium">{calculation.carbBolus} units</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">BG Correction:</span>
                  <span className="font-medium">{calculation.correctionBolus} units</span>
                </div>
                <hr/>
                <div className="flex justify-between items-center text-blue-700">
                  <span className="text-lg font-bold">Suggested Dose:</span>
                  <span className="text-2xl font-bold">{calculation.totalBolus} units</span>
                </div>
              </div>
            )}
            
            <div className="bg-red-50 border-l-4 border-red-400 text-red-800 p-4 rounded-md">
              <div className="flex">
                <div className="flex-shrink-0"><AlertTriangle className="h-5 w-5" /></div>
                <div className="ml-3">
                  <p className="text-sm font-medium">
                    This is only a suggestion. This tool is not a medical device. Always verify the dose with your pump and personal treatment plan.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          {settings && (
            <Button onClick={handleSaveAndClose} disabled={!calculation}>
              Save Meal with Dose
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
