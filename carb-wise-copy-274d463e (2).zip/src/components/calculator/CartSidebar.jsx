
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ShoppingCart, Minus, Plus, Save, Trash2, Zap } from "lucide-react";

export default function CartSidebar({ cart, totals, onUpdateQuantity, onRemoveItem, onSaveMeal, onClearCart, onCalculateDose }) {
  if (cart.length === 0) {
    return (
      <Card className="sticky top-4">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <ShoppingCart className="w-5 h-5" />
            Your Order
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-medium text-gray-700">Ready to build your meal?</p>
            <p className="text-sm">Knowledge is power. Select any item from the menu to begin tracking.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="sticky top-4">
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-lg">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Your Order
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onClearCart}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3 max-h-80 overflow-y-auto">
          {cart.map((item, index) => (
            <div key={index} className="p-3 bg-gray-50 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 text-sm">{item.name}</h4>
                  <p className="text-xs text-gray-500 capitalize">{item.size}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onRemoveItem(index)}
                  className="p-1 h-auto text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex gap-3 text-xs">
                  <Badge variant="outline" className="bg-blue-50 text-blue-700">
                    {item.carbs}g carbs
                  </Badge>
                  <span className="text-gray-600">{item.calories} cal</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onUpdateQuantity(index, Math.max(1, item.quantity - 1))}
                    className="w-6 h-6 p-0"
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                    className="w-6 h-6 p-0"
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <Separator />

        <div className="space-y-3">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex justify-between items-center mb-2">
              <span className="font-semibold text-gray-900">Total Carbohydrates</span>
              <span className="text-2xl font-bold text-blue-600">{totals.carbs}g</span>
            </div>
            <div className="flex justify-between items-center text-sm text-gray-600">
              <span>Total Calories</span>
              <span className="font-medium">{totals.calories}</span>
            </div>
          </div>
          
          <Button
            onClick={onCalculateDose}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Zap className="w-4 h-4 mr-2" />
            Calculate Insulin Dose
          </Button>

          <Button
            onClick={onSaveMeal}
            className="w-full bg-green-600 hover:bg-green-700 text-white"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Meal
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
