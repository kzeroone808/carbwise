
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, Star, Check, Lock } from "lucide-react";

const restaurants = [
  // Fast Food
  { id: "mcdonalds", name: "McDonald's", color: "bg-yellow-500", icon: "🍟" },
  { id: "subway", name: "Subway", color: "bg-green-600", icon: "🥪" },
  { id: "starbucks", name: "Starbucks", color: "bg-green-700", icon: "☕" },
  { id: "burger_king", name: "Burger King", color: "bg-blue-500", icon: "👑" },
  { id: "taco_bell", name: "Taco Bell", color: "bg-purple-600", icon: "🌮" },
  { id: "pizza_hut", name: "Pizza Hut", color: "bg-red-600", icon: "🍕" },
  { id: "kfc", name: "KFC", color: "bg-red-700", icon: "🍗" },
  { id: "chipotle", name: "Chipotle", color: "bg-stone-800", icon: "🌯" },
  { id: "panera", name: "Panera Bread", color: "bg-green-800", icon: "🥐" },
  { id: "dunkin", name: "Dunkin'", color: "bg-pink-500", icon: "🍩" },
  
  // Premium brands
  { id: "chick-fil-a", name: "Chick-fil-A", color: "bg-red-600", icon: "🐄" },
  { id: "wendys", name: "Wendy's", color: "bg-red-500", icon: "👧" },
  { id: "dominos", name: "Domino's", color: "bg-blue-700", icon: "🎲" },
  { id: "popeyes", name: "Popeyes", color: "bg-orange-600", icon: "🌶️" },
  { id: "arbys", name: "Arby's", color: "bg-red-800", icon: "🤠" },
  { id: "panda_express", name: "Panda Express", color: "bg-red-600", icon: "🐼" },
  { id: "sonic", name: "Sonic", color: "bg-blue-500", icon: "🚗" },
  { id: "jack_in_the_box", name: "Jack in the Box", color: "bg-yellow-400", icon: "🤡" },
  { id: "five_guys", name: "Five Guys", color: "bg-red-600", icon: "🍔" },
  { id: "in_n_out", name: "In-N-Out", color: "bg-yellow-600", icon: "🌴" },
  { id: "shake_shack", name: "Shake Shack", color: "bg-green-500", icon: "🥤" },
  { id: "whataburger", name: "Whataburger", color: "bg-orange-600", icon: "🤠" },
  { id: "del_taco", name: "Del Taco", color: "bg-red-600", icon: "🌮" },
  { id: "carls_jr", name: "Carl's Jr.", color: "bg-red-700", icon: "⭐" },
  { id: "hardees", name: "Hardee's", color: "bg-red-700", icon: "⭐" },
  { id: "white_castle", name: "White Castle", color: "bg-blue-700", icon: "🏰" },
  { id: "culvers", name: "Culver's", color: "bg-blue-600", icon: "🧀" },
  { id: "raising_canes", name: "Raising Cane's", color: "bg-yellow-500", icon: "🐔" },
  { id: "bojangles", name: "Bojangles", color: "bg-blue-800", icon: "🍗" },
  { id: "zaxbys", name: "Zaxby's", color: "bg-orange-700", icon: "🍗" },
  { id: "wingstop", name: "Wingstop", color: "bg-orange-500", icon: "🍗" },
  { id: "buffalo_wild_wings", name: "Buffalo Wild Wings", color: "bg-yellow-600", icon: "🦬" },
  { id: "jersey_mikes", name: "Jersey Mike's", color: "bg-blue-800", icon: "🥪" },
  { id: "jimmy_johns", name: "Jimmy John's", color: "bg-red-700", icon: "🥪" },
  
  // Casual Dining
  { id: "applebees", name: "Applebee's", color: "bg-red-800", icon: "🍎" },
  { id: "chilis", name: "Chili's", color: "bg-red-700", icon: "🌶️" },
  { id: "olive_garden", name: "Olive Garden", color: "bg-green-700", icon: "🫒" },
  { id: "red_lobster", name: "Red Lobster", color: "bg-red-600", icon: "🦞" },
  { id: "outback", name: "Outback Steakhouse", color: "bg-orange-800", icon: "🥩" },
  { id: "texas_roadhouse", name: "Texas Roadhouse", color: "bg-yellow-800", icon: "🤠" },
  { id: "cheesecake_factory", name: "Cheesecake Factory", color: "bg-purple-700", icon: "🍰" },
  { id: "pf_changs", name: "P.F. Chang's", color: "bg-red-900", icon: "🥢" },
  { id: "tgi_fridays", name: "TGI Fridays", color: "bg-red-700", icon: "🎉" },
  { id: "red_robin", name: "Red Robin", color: "bg-red-600", icon: "🐦" },
  { id: "longhorn_steakhouse", name: "LongHorn Steakhouse", color: "bg-orange-900", icon: "🥩" },
  
  // More Pizza
  { id: "papa_johns", name: "Papa John's", color: "bg-green-700", icon: "🍕" },
  { id: "little_caesars", name: "Little Caesars", color: "bg-orange-700", icon: "🍕" },
  { id: "papa_murphys", name: "Papa Murphy's", color: "bg-red-500", icon: "🍕" },
  { id: "blaze_pizza", name: "Blaze Pizza", color: "bg-red-500", icon: "🔥" },
  { id: "mod_pizza", name: "MOD Pizza", color: "bg-blue-600", icon: "🍕" },
  
  // Mexican
  { id: "qdoba", name: "Qdoba", color: "bg-red-700", icon: "🌶️" },
  { id: "moes", name: "Moe's Southwest Grill", color: "bg-yellow-700", icon: "🎉" },
  { id: "el_pollo_loco", name: "El Pollo Loco", color: "bg-yellow-600", icon: "🐓" },
  
  // Breakfast
  { id: "ihop", name: "IHOP", color: "bg-blue-600", icon: "🥞" },
  { id: "dennys", name: "Denny's", color: "bg-yellow-600", icon: "🍳" },
  { id: "cracker_barrel", name: "Cracker Barrel", color: "bg-yellow-700", icon: "🏠" },
  { id: "waffle_house", name: "Waffle House", color: "bg-yellow-500", icon: "🧇" }
];

const publicSchools = [
  { id: "la_unified_school_district", name: "Los Angeles USD", color: "bg-blue-800", icon: "🏫" },
  { id: "nyc_department_of_education", name: "NYC Dept. of Education", color: "bg-orange-600", icon: "🏫" },
  { id: "chicago_public_schools", name: "Chicago Public Schools", color: "bg-red-700", icon: "🏫" },
  { id: "miami_dade_public_schools", name: "Miami-Dade County", color: "bg-teal-500", icon: "🏫" },
  { id: "houston_isd", name: "Houston ISD", color: "bg-indigo-600", icon: "🏫" },
  { id: "clark_county_schools", name: "Clark County (Las Vegas)", color: "bg-purple-600", icon: "🏫" },
  { id: "broward_county_schools", name: "Broward County", color: "bg-green-600", icon: "🏫" },
  { id: "hillsborough_county_schools", name: "Hillsborough County", color: "bg-yellow-600", icon: "🏫" },
  { id: "orange_county_schools", name: "Orange County", color: "bg-pink-600", icon: "🏫" },
  { id: "fairfax_county_schools", name: "Fairfax County", color: "bg-cyan-600", icon: "🏫" },
  { id: "wake_county_schools", name: "Wake County", color: "bg-lime-600", icon: "🏫" },
  { id: "gwinnett_county_schools", name: "Gwinnett County", color: "bg-amber-600", icon: "🏫" }
];


export default function RestaurantGrid({ onSelectRestaurant, selectedRestaurants = [], userTier = "free" }) {
  const getMaxSelections = (tier) => {
    switch (tier) {
      case 'free': return 3;
      case 'premium': return 6;
      case 'premium_plus': return Infinity;
      default: return 3;
    }
  };

  const maxSelections = getMaxSelections(userTier);

  return (
    <div className="space-y-12">
      <div>
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Restaurants</h3>
        {/* Subscription Status Card */}
        <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {userTier === 'free' && <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">F</div>}
                {userTier === 'premium' && <Crown className="w-8 h-8 text-yellow-600" />}
                {userTier === 'premium_plus' && <Star className="w-8 h-8 text-purple-600" />}
                <div>
                  <h3 className="font-bold text-lg capitalize">{userTier.replace('_', ' ')} Plan</h3>
                  <p className="text-sm text-gray-600">
                    {userTier === 'premium_plus' 
                      ? 'Unlimited restaurant access' 
                      : `${selectedRestaurants.filter(id => restaurants.some(r => r.id === id)).length} of ${maxSelections === Infinity ? 'unlimited' : maxSelections} restaurants available`}
                  </p>
                </div>
              </div>
              {userTier !== 'premium_plus' && (
                <div className="text-right">
                  <Badge variant="outline" className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                    {userTier === 'free' ? 'Upgrade for more access' : 'Upgrade for unlimited'}
                  </Badge>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Restaurant Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {restaurants.map((restaurant) => {
            const isSelected = selectedRestaurants.includes(restaurant.id);
            // Logic for `canSelect` ensures:
            // 1. If already selected, it can always be clicked (to deselect).
            // 2. Premium Plus users can always select any restaurant.
            // 3. Other tiers can select if there are selections remaining and they are not Premium Plus.
            const canSelect = isSelected || 
                              userTier === 'premium_plus' || 
                              (selectedRestaurants.filter(id => restaurants.some(r => r.id === id)).length < maxSelections && userTier !== 'premium_plus');
            
            return (
              <RestaurantCard 
                key={restaurant.id}
                restaurant={restaurant}
                isSelected={isSelected}
                canSelect={canSelect}
                userTier={userTier}
                onClick={() => onSelectRestaurant(restaurant.id)}
              />
            );
          })}
        </div>
      </div>

      <div>
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Public Schools</h3>
        <Card className="bg-gradient-to-r from-teal-50 to-cyan-50 border-teal-200 mb-6">
            <CardContent className="p-4">
                <p className="text-sm text-teal-800">Select a school district to access a menu of common cafeteria items. This feature is available to all users.</p>
            </CardContent>
        </Card>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {publicSchools.map((school) => (
                <RestaurantCard
                    key={school.id}
                    restaurant={school}
                    isSelected={selectedRestaurants.includes(school.id)}
                    canSelect={true} // Schools are always selectable
                    userTier={userTier}
                    onClick={() => onSelectRestaurant(school.id)}
                />
            ))}
        </div>
      </div>

      {/* Upgrade Prompt - only show for non-Premium Plus users */}
      {userTier !== 'premium_plus' && (
        <Card className="bg-gradient-to-r from-purple-100 to-blue-100 border-purple-200">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Crown className="w-6 h-6 text-purple-600" />
              <h3 className="text-xl font-bold text-purple-900">Want Access to All Restaurants?</h3>
            </div>
            <p className="text-purple-700 mb-4">
              {userTier === 'free' 
                ? `Upgrade to Premium for ${getMaxSelections('premium')} picks, or Premium Plus for unlimited access to all ${restaurants.length}+ restaurants!`
                : 'Upgrade to Premium Plus for unlimited access to all restaurants!'}
            </p>
            <div className="flex gap-3 justify-center">
              {userTier === 'free' && (
                <Badge className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-white px-4 py-2">
                  Premium - $4.99/month
                </Badge>
              )}
              <Badge className="bg-gradient-to-r from-purple-500 to-purple-700 text-white px-4 py-2">
                Premium Plus - $9.99/month
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function RestaurantCard({ restaurant, isSelected, canSelect, userTier, onClick }) {
  return (
    <Card
      className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
        !canSelect && userTier !== 'premium_plus' ? 'opacity-60' : 'hover:shadow-lg'
      } ${
        isSelected ? 'ring-2 ring-blue-500 shadow-lg' : 'hover:shadow-md'
      }`}
      onClick={onClick}
    >
      <CardContent className="p-4 text-center relative">
        {isSelected && (
          <div className="absolute top-2 right-2">
            <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
              <Check className="w-4 h-4 text-white" />
            </div>
          </div>
        )}
        {!isSelected && !canSelect && userTier !== 'premium_plus' && (
          <div className="absolute top-2 right-2">
            <div className="w-6 h-6 bg-gray-400 rounded-full flex items-center justify-center">
              <Lock className="w-4 h-4 text-white" />
            </div>
          </div>
        )}
        
        <div className={`w-12 h-12 ${restaurant.color} rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-3 ${
          !canSelect && userTier !== 'premium_plus' ? 'grayscale' : ''
        }`}>
          {restaurant.icon}
        </div>
        <h3 className={`font-semibold text-sm ${!canSelect && userTier !== 'premium_plus' ? 'text-gray-400' : 'text-gray-900'}`}>
          {restaurant.name}
        </h3>
        {isSelected && (
          <Badge className="mt-1 text-xs bg-blue-100 text-blue-700">
            Selected
          </Badge>
        )}
        {!isSelected && !canSelect && userTier !== 'premium_plus' && (
          <Badge className="mt-1 text-xs bg-gray-100 text-gray-500">
            Premium
          </Badge>
        )}
      </CardContent>
    </Card>
  );
}
