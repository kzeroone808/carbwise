import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function NutritionModal({ isOpen, onClose, item, size, sizeData }) {
  if (!item || !sizeData) return null;

  const nutritionFacts = [
    { label: "Calories", value: sizeData.calories, unit: "" },
    { label: "Total Fat", value: sizeData.total_fat, unit: "g" },
    { label: "Saturated Fat", value: sizeData.saturated_fat, unit: "g", indent: true },
    { label: "Trans Fat", value: sizeData.trans_fat, unit: "g", indent: true },
    { label: "Cholesterol", value: sizeData.cholesterol, unit: "mg" },
    { label: "Sodium", value: sizeData.sodium, unit: "mg" },
    { label: "Total Carbohydrates", value: sizeData.carbs, unit: "g", highlight: true },
    { label: "Dietary Fiber", value: sizeData.dietary_fiber, unit: "g", indent: true },
    { label: "Total Sugars", value: sizeData.sugars, unit: "g", indent: true },
    { label: "Added Sugars", value: sizeData.added_sugars, unit: "g", indent: true },
    { label: "Protein", value: sizeData.protein, unit: "g" }
  ];

  const vitaminsAndMinerals = [
    { label: "Vitamin D", value: sizeData.vitamin_d, unit: "mcg" },
    { label: "Calcium", value: sizeData.calcium, unit: "mg" },
    { label: "Iron", value: sizeData.iron, unit: "mg" },
    { label: "Potassium", value: sizeData.potassium, unit: "mg" },
    { label: "Vitamin A", value: sizeData.vitamin_a, unit: "mcg RAE" },
    { label: "Vitamin C", value: sizeData.vitamin_c, unit: "mg" }
  ];

  if (sizeData.caffeine && sizeData.caffeine > 0) {
    vitaminsAndMinerals.push({ label: "Caffeine", value: sizeData.caffeine, unit: "mg" });
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">
            {item.name} - {size.charAt(0).toUpperCase() + size.slice(1)}
          </DialogTitle>
          <p className="text-sm text-gray-600 capitalize">
            {item.restaurant.replace(/_/g, ' ')} • {item.category.replace(/_/g, ' ')}
          </p>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh]">
          <div className="space-y-4">
            {/* Nutrition Facts Label */}
            <div className="bg-white border-2 border-black p-4 font-mono">
              <div className="text-center">
                <h3 className="text-2xl font-bold border-b-4 border-black pb-1">Nutrition Facts</h3>
                <p className="text-sm mt-1">Per serving</p>
              </div>
              
              <div className="mt-4 space-y-1">
                {nutritionFacts.map((fact, index) => {
                  if (fact.value === undefined || fact.value === null) return null;
                  
                  return (
                    <div key={index} className={`flex justify-between ${
                      fact.indent ? 'pl-4 text-sm' : ''
                    } ${fact.highlight ? 'font-bold bg-blue-50 px-2 py-1 rounded' : ''} ${
                      index === 0 ? 'text-2xl font-bold border-b-4 border-black pb-2' : ''
                    } ${index === 6 ? 'border-t border-black pt-1' : ''}`}>
                      <span>{fact.label}</span>
                      <span className="font-bold">{fact.value}{fact.unit}</span>
                    </div>
                  );
                })}
              </div>
              
              <Separator className="my-3 border-black" />
              
              <div className="space-y-1">
                <p className="text-xs font-bold">Vitamins & Minerals</p>
                {vitaminsAndMinerals.map((vitamin, index) => {
                  if (vitamin.value === undefined || vitamin.value === null || vitamin.value === 0) return null;
                  
                  return (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{vitamin.label}</span>
                      <span>{vitamin.value}{vitamin.unit}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Allergens */}
            {item.allergens && item.allergens.length > 0 && (
              <div>
                <h4 className="font-semibold mb-2">Allergens</h4>
                <div className="flex flex-wrap gap-2">
                  {item.allergens.map((allergen) => (
                    <Badge key={allergen} variant="outline" className="bg-red-50 text-red-800 border-red-200">
                      {allergen.replace(/_/g, ' ')}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Ingredients */}
            {item.ingredients && (
              <div>
                <h4 className="font-semibold mb-2">Ingredients</h4>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {item.ingredients}
                </p>
              </div>
            )}

            {/* Key Nutritional Highlights */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold mb-2 text-blue-900">Key Facts for Diabetes Management</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-blue-800">Total Carbs:</span>
                  <div className="text-2xl font-bold text-blue-900">{sizeData.carbs}g</div>
                </div>
                {sizeData.dietary_fiber > 0 && (
                  <div>
                    <span className="font-medium text-blue-800">Fiber:</span>
                    <div className="text-lg font-semibold text-blue-900">{sizeData.dietary_fiber}g</div>
                  </div>
                )}
                {sizeData.sugars > 0 && (
                  <div>
                    <span className="font-medium text-blue-800">Sugars:</span>
                    <div className="text-lg font-semibold text-blue-900">{sizeData.sugars}g</div>
                  </div>
                )}
                {sizeData.protein > 0 && (
                  <div>
                    <span className="font-medium text-blue-800">Protein:</span>
                    <div className="text-lg font-semibold text-blue-900">{sizeData.protein}g</div>
                  </div>
                )}
              </div>
              
              {sizeData.dietary_fiber > 0 && (
                <div className="mt-3 p-2 bg-green-100 rounded text-xs text-green-800">
                  <strong>Net Carbs:</strong> {Math.max(0, sizeData.carbs - sizeData.dietary_fiber)}g
                  <br />
                  <em>Total carbs minus fiber</em>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}