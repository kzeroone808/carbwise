import React, { useState } from "react";
import { FoodItem } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";

export default function CustomItemForm({ open, onOpenChange, onSuccess, restaurant }) {
  const [name, setName] = useState("");
  const [carbs, setCarbs] = useState("");
  const [calories, setCalories] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async () => {
    if (!name || !carbs) return;
    setIsProcessing(true);
    
    try {
      await FoodItem.create({
        name,
        restaurant: restaurant || "custom",
        category: "custom",
        sizes: {
          medium: {
            carbs: parseFloat(carbs),
            calories: calories ? parseFloat(calories) : 0,
            price: 0
          }
        },
        is_custom: true
      });
      
      setName("");
      setCarbs("");
      setCalories("");
      onSuccess();
    } catch (error) {
      console.error("Failed to create custom item:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add a Custom Food Item</DialogTitle>
          <DialogDescription>
            Can't find an item? Add it here to include it in your meal calculation.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="item-name">Item Name</Label>
            <Input id="item-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., House Special Pizza" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="item-carbs">Carbs (g)</Label>
              <Input id="item-carbs" type="number" value={carbs} onChange={(e) => setCarbs(e.target.value)} placeholder="e.g., 55" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="item-calories">Calories (optional)</Label>
              <Input id="item-calories" type="number" value={calories} onChange={(e) => setCalories(e.target.value)} placeholder="e.g., 800" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isProcessing}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isProcessing || !name || !carbs}>
            {isProcessing ? "Saving..." : "Save Item"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}