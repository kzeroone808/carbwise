
import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

const getExactItemImage = (restaurant, itemName) => {
  // Normalize the item name for better matching
  const normalizedName = itemName.toLowerCase().replace(/[^\w\s]/g, '').replace(/\s+/g, ' ').trim();
  
  // Exact item name matching - most specific
  const exactMatches = {
    // McDonald's - verified food images only
    'big mac': "https://images.unsplash.com/photo-1553979459-d2229ba7433a?w=400&h=300&fit=crop",
    'quarter pounder with cheese': "https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=400&h=300&fit=crop",
    'double quarter pounder with cheese': "https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400&h=300&fit=crop",
    'mcdouble': "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=400&h=300&fit=crop",
    'cheeseburger': "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=400&h=300&fit=crop",
    'hamburger': "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop",
    'mcchicken': "https://images.unsplash.com/photo-1606755962773-d324e2dabd3f?w=400&h=300&fit=crop",
    'spicy mcchicken': "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=400&h=300&fit=crop",
    'filet o fish': "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop",
    'chicken mcnuggets': "https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=400&h=300&fit=crop",
    'french fries': "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop",
    'hash browns': "https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?w=400&h=300&fit=crop",
    'apple slices': "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&h=300&fit=crop",
    'egg mcmuffin': "https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=400&h=300&fit=crop",
    'sausage mcmuffin with egg': "https://images.unsplash.com/photo-1506084868230-bb9d95c24759?w=400&h=300&fit=crop",
    'bacon egg cheese mcgriddles': "https://images.unsplash.com/photo-1587563871167-1ee5c3a8b931?w=400&h=300&fit=crop",
    'hotcakes': "https://images.unsplash.com/photo-1554520735-0a6b8b6ce8b7?w=400&h=300&fit=crop",
    'big breakfast': "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=400&h=300&fit=crop",
    'fruit maple oatmeal': "https://images.unsplash.com/photo-1595034654338-a92448742b26?w=400&h=300&fit=crop",
    'mcflurry with oreo cookies': "https://images.unsplash.com/photo-1570197788417-0e82375c9371?w=400&h=300&fit=crop",
    'baked apple pie': "https://images.unsplash.com/photo-1621955964441-c173e01c135b?w=400&h=300&fit=crop",
    'chocolate chip cookie': "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&h=300&fit=crop",
    'vanilla shake': "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=400&h=300&fit=crop",
    'coca cola': "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?w=400&h=300&fit=crop",
    'coffee': "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?w=400&h=300&fit=crop",
    
    // Subway - sandwich images
    'turkey breast sandwich': "https://images.unsplash.com/photo-1539252554453-80ab65ce3586?w=400&h=300&fit=crop",
    'italian bmt': "https://images.unsplash.com/photo-1555072956-7758afb20e8f?w=400&h=300&fit=crop",
    'meatball marinara': "https://images.unsplash.com/photo-1594007654729-407eedc4be65?w=400&h=300&fit=crop",
    'chicken teriyaki': "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop",
    'steak cheese': "https://images.unsplash.com/photo-1553909489-cd47e0ef937f?w=400&h=300&fit=crop",
    'tuna': "https://images.unsplash.com/photo-1509722747041-616f39b57569?w=400&h=300&fit=crop",
    'veggie delite': "https://images.unsplash.com/photo-1512852939750-1305098529bf?w=400&h=300&fit=crop",
    
    // Starbucks - coffee and food
    'pike place roast': "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?w=400&h=300&fit=crop",
    'caffe latte': "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&h=300&fit=crop",
    'cappuccino': "https://images.unsplash.com/photo-1572286258217-aac48775b773?w=400&h=300&fit=crop",
    'caramel macchiato': "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
    'white chocolate mocha': "https://images.unsplash.com/photo-1544787219-7f048d60b8b5?w=400&h=300&fit=crop",
    'iced coffee': "https://images.unsplash.com/photo-1517701550927-4e4b7da17931?w=400&h=300&fit=crop",
    'frappuccino': "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=400&h=300&fit=crop",
    'bacon gouda egg sandwich': "https://images.unsplash.com/photo-1482049016688-2d3e1b311543?w=400&h=300&fit=crop",
    'croissant': "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&h=300&fit=crop",
    'blueberry muffin': "https://images.unsplash.com/photo-1607958996333-41aef7caefaa?w=400&h=300&fit=crop",
    
    // Burger King
    'whopper': "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop",
    'impossible whopper': "https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=400&h=300&fit=crop",
    'bacon king': "https://images.unsplash.com/photo-1553979459-d2229ba7433a?w=400&h=300&fit=crop",
    'chicken sandwich': "https://images.unsplash.com/photo-1606755962773-d324e2dabd3f?w=400&h=300&fit=crop",
    'chicken nuggets': "https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=400&h=300&fit=crop",
    'onion rings': "https://images.unsplash.com/photo-1639024471283-03518883512d?w=400&h=300&fit=crop",
    
    // Taco Bell - Mexican food
    'crunchy taco': "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=400&h=300&fit=crop",
    'soft taco': "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=400&h=300&fit=crop",
    'cheesy gordita crunch': "https://images.unsplash.com/photo-1609501676725-7186f3d37e1a?w=400&h=300&fit=crop",
    'chalupa supreme': "https://images.unsplash.com/photo-1604467794349-0b74285de7a7?w=400&h=300&fit=crop",
    'crunchwrap supreme': "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=400&h=300&fit=crop",
    'quesadilla': "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop",
    'burrito': "https://images.unsplash.com/photo-1574343635718-467b5d714e13?w=400&h=300&fit=crop",
    'nachos': "https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=400&h=300&fit=crop",
    
    // Pizza Hut
    'pepperoni pizza': "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop",
    'supreme pizza': "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400&h=300&fit=crop",
    'meat lovers pizza': "https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=400&h=300&fit=crop",
    'stuffed crust pizza': "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=400&h=300&fit=crop",
    'breadsticks': "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=300&fit=crop",
    
    // KFC
    'original recipe chicken': "https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400&h=300&fit=crop",
    'extra crispy chicken': "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=400&h=300&fit=crop",
    'famous bowl': "https://images.unsplash.com/photo-1544025162-d76694265947?w=400&h=300&fit=crop",
    'mashed potatoes': "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=400&h=300&fit=crop",
    'coleslaw': "https://images.unsplash.com/photo-1505253213348-cd54c92b37eb?w=400&h=300&fit=crop",
    'biscuit': "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=300&fit=crop",
    
    // Chipotle
    'chicken bowl': "https://images.unsplash.com/photo-1544025162-d76694265947?w=400&h=300&fit=crop",
    'steak bowl': "https://images.unsplash.com/photo-1544025162-d76694265947?w=400&h=300&fit=crop",
    'chicken burrito': "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=400&h=300&fit=crop",
    'chips': "https://images.unsplash.com/photo-1601924582970-9238bcb495d9?w=400&h=300&fit=crop",
    'guacamole': "https://images.unsplash.com/photo-1553787499-6f0ba9a8cc13?w=400&h=300&fit=crop",
    
    // Chick-fil-A
    'chick fil a chicken sandwich': "https://images.unsplash.com/photo-1606755962773-d324e2dabd3f?w=400&h=300&fit=crop",
    'spicy chicken sandwich': "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=400&h=300&fit=crop",
    'chick fil a nuggets': "https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=400&h=300&fit=crop",
    'waffle potato fries': "https://images.unsplash.com/photo-1630030075847-0efcf9de26a9?w=400&h=300&fit=crop",
    
    // Wendy's
    'daves single': "https://images.unsplash.com/photo-1553979459-d2229ba7433a?w=400&h=300&fit=crop",
    'baconator': "https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400&h=300&fit=crop",
    'classic chicken sandwich': "https://images.unsplash.com/photo-1606728035253-49e8a23146de?w=400&h=300&fit=crop",
    'chili': "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop",
    'chocolate frosty': "https://images.unsplash.com/photo-1541544181051-e46607bc22a4?w=400&h=300&fit=crop",
    
    // Domino's
    'dominos pepperoni pizza': "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop",
    'meatzza pizza': "https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=400&h=300&fit=crop",
    'stuffed cheesy bread': "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=400&h=300&fit=crop",
    'bread twists': "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop",
    
    // Popeyes
    'popeyes chicken sandwich': "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=400&h=300&fit=crop",
    'fried chicken': "https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400&h=300&fit=crop",
    'red beans and rice': "https://images.unsplash.com/photo-1544025162-d76694265947?w=400&h=300&fit=crop",
    'biscuits': "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=300&fit=crop"
  };

  // Try exact match first
  if (exactMatches[normalizedName]) {
    return exactMatches[normalizedName];
  }

  // Try partial matching for common food words
  const partialMatches = {
    'burger': "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop",
    'chicken': "https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400&h=300&fit=crop",
    'sandwich': "https://images.unsplash.com/photo-1539252554453-80ab65ce3586?w=400&h=300&fit=crop",
    'pizza': "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop",
    'taco': "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=400&h=300&fit=crop",
    'burrito': "https://images.unsplash.com/photo-1574343635718-467b5d714e13?w=400&h=300&fit=crop",
    'fries': "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop",
    'coffee': "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?w=400&h=300&fit=crop",
    'latte': "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&h=300&fit=crop",
    'shake': "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=400&h=300&fit=crop",
    'salad': "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=400&h=300&fit=crop",
    'nuggets': "https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=400&h=300&fit=crop",
    'pancakes': "https://images.unsplash.com/photo-1554520735-0a6b8b6ce8b7?w=400&h=300&fit=crop",
    'muffin': "https://images.unsplash.com/photo-1607958996333-41aef7caefaa?w=400&h=300&fit=crop",
    'cookie': "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&h=300&fit=crop",
    'pie': "https://images.unsplash.com/photo-1621955964441-c173e01c135b?w=400&h=300&fit=crop"
  };

  // Check for partial matches
  for (const [keyword, imageUrl] of Object.entries(partialMatches)) {
    if (normalizedName.includes(keyword)) {
      return imageUrl;
    }
  }

  // Category-based fallback
  const categoryImages = {
    'burgers': "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop",
    'chicken': "https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400&h=300&fit=crop",
    'sandwiches': "https://images.unsplash.com/photo-1539252554453-80ab65ce3586?w=400&h=300&fit=crop",
    'pizza': "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop",
    'sides': "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop",
    'breakfast': "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=400&h=300&fit=crop",
    'desserts': "https://images.unsplash.com/photo-1570197788417-0e82375c9371?w=400&h=300&fit=crop",
    'beverages': "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?w=400&h=300&fit=crop",
    'coffee': "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?w=400&h=300&fit=crop",
    'salads': "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=400&h=300&fit=crop",
    'mexican': "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=400&h=300&fit=crop"
  };

  // Check for category matches if no exact or partial match found
  for (const [category, imageUrl] of Object.entries(categoryImages)) {
    // Check if the normalized item name contains the category keyword or its singular form
    const singularCategory = category.endsWith('s') && category.length > 1 ? category.slice(0, -1) : category;
    if (normalizedName.includes(singularCategory) || normalizedName.includes(category)) {
      return imageUrl;
    }
  }

  // Final fallback to appropriate food image
  return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop";
};

// NutritionModal Component
function NutritionModal({ isOpen, onClose, item, size, sizeData }) {
  if (!sizeData) return null;

  const nutritionFacts = [
    { label: "Calories", value: sizeData.calories, unit: "cal" },
    { label: "Protein", value: sizeData.protein, unit: "g" },
    { label: "Carbs", value: sizeData.carbs, unit: "g" },
    { label: "Fat", value: sizeData.fat, unit: "g" },
    { label: "Sugar", value: sizeData.sugar, unit: "g" },
    { label: "Sodium", value: sizeData.sodium, unit: "mg" },
    { label: "Fiber", value: sizeData.fiber, unit: "g" },
  ].filter(fact => fact.value !== undefined && fact.value !== null); // Filter out undefined/null values

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {item.name} ({size ? size.charAt(0).toUpperCase() + size.slice(1) : ''}) Nutrition Facts
          </DialogTitle>
          <DialogDescription>
            Detailed nutritional information for this item.
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-72 w-full pr-4"> {/* Add pr-4 for scrollbar space */}
          <div className="grid grid-cols-2 gap-4 py-4">
            {nutritionFacts.map((fact) => (
              <div key={fact.label} className="flex items-center justify-between">
                <span className="font-medium">{fact.label}:</span>
                <span className="text-gray-700">{fact.value}{fact.unit}</span>
              </div>
            ))}
            {sizeData.price > 0 && (
              <div className="flex items-center justify-between col-span-2 text-lg font-bold text-green-600 mt-2">
                <span>Price:</span>
                <span>${sizeData.price.toFixed(2)}</span>
              </div>
            )}
          </div>
        </ScrollArea>
        <Button onClick={onClose} className="w-full mt-4">Close</Button>
      </DialogContent>
    </Dialog>
  );
}

export default function FoodItemCard({ item, onAddToCart }) {
  const [showNutrition, setShowNutrition] = useState(false);
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedSizeData, setSelectedSizeData] = useState(null);

  const getSizeOptions = () => {
    const sizes = [];
    if (item.sizes?.small) sizes.push({ key: 'small', label: 'Small', data: item.sizes.small });
    if (item.sizes?.medium) sizes.push({ key: 'medium', label: 'Medium', data: item.sizes.medium });
    if (item.sizes?.large) sizes.push({ key: 'large', label: 'Large', data: item.sizes.large });
    return sizes;
  };

  const sizeOptions = getSizeOptions();
  const itemImage = getExactItemImage(item.restaurant, item.name);

  const handleShowNutrition = (size, sizeData) => {
    setSelectedSize(size);
    setSelectedSizeData(sizeData);
    setShowNutrition(true);
  };

  return (
    <>
      <Card className="hover:shadow-lg transition-all duration-200 border border-gray-200 overflow-hidden">
        <div className="relative">
          <img
            src={itemImage}
            alt={item.name}
            className="w-full h-48 object-cover"
            loading="lazy"
          />
          {item.is_custom && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-yellow-500 text-white">⭐ My Item</Badge>
            </div>
          )}
          <div className="absolute bottom-2 left-2">
            <Badge variant="outline" className="bg-white/90 text-xs capitalize">
              {item.category?.replace(/_/g, ' ')}
            </Badge>
          </div>
        </div>
        <CardHeader className="pb-3">
          <h3 className="text-lg font-semibold text-gray-900 leading-tight">{item.name}</h3>
        </CardHeader>
        <CardContent className="space-y-3">
          {sizeOptions.map((size) => (
            <div key={size.key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-gray-900">{size.label}</span>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs px-2 py-1 h-auto"
                      onClick={() => handleShowNutrition(size.key, size.data)}
                    >
                      Nutrition
                    </Button>
                    <Button
                      size="sm"
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4"
                      onClick={() => onAddToCart(item, size.key, size.data)}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                </div>
                <div className="flex gap-4 text-sm">
                  <span className="font-semibold text-blue-600">{size.data.carbs}g carbs</span>
                  <span className="text-gray-600">{size.data.calories} cal</span>
                  {size.data.protein > 0 && (
                    <span className="text-green-600">{size.data.protein}g protein</span>
                  )}
                  {size.data.price > 0 && (
                    <span className="text-green-600 font-medium">${size.data.price.toFixed(2)}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <NutritionModal 
        isOpen={showNutrition}
        onClose={() => setShowNutrition(false)}
        item={item}
        size={selectedSize}
        sizeData={selectedSizeData}
      />
    </>
  );
}
