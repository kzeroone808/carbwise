import React, { useState, useEffect } from 'react';
import { InvokeLLM } from "@/api/integrations";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, TrendingUp, TrendingDown, Brain, Phone } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function GlucoseAI({ currentBG, trend, recentReadings = [] }) {
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [userSettings, setUserSettings] = useState(null);

  useEffect(() => {
    loadUserSettings();
  }, []);

  useEffect(() => {
    if (currentBG && userSettings) {
      analyzeGlucose();
    }
  }, [currentBG, trend, userSettings]);

  const loadUserSettings = async () => {
    try {
      const user = await User.me();
      if (user) {
        setUserSettings({
          targetBG: user.targetBloodGlucose || 100,
          icr: user.insulinToCarbRatio,
          isf: user.insulinSensitivityFactor
        });
      }
    } catch (error) {
      console.error("Failed to load user settings:", error);
    }
  };

  const analyzeGlucose = async () => {
    if (!currentBG || isAnalyzing) return;
    
    setIsAnalyzing(true);
    try {
      const prompt = `You are an expert diabetes management AI assistant. Analyze this blood glucose situation and provide actionable guidance:

Current BG: ${currentBG} mg/dL
Trend: ${trend}
Target BG: ${userSettings?.targetBG || 100} mg/dL
User's ICR: ${userSettings?.icr || 'Not set'}
User's ISF: ${userSettings?.isf || 'Not set'}
Recent readings: ${recentReadings.join(', ')} mg/dL

Analyze this situation and provide:
1. Risk level assessment (LOW/MODERATE/HIGH/CRITICAL)
2. Immediate actions the user should take
3. When to seek medical help
4. Prevention tips for the future

Be specific, actionable, and prioritize safety. If this is a critical situation, emphasize emergency actions.`;

      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            riskLevel: { type: "string", enum: ["LOW", "MODERATE", "HIGH", "CRITICAL"] },
            primaryMessage: { type: "string" },
            immediateActions: { 
              type: "array", 
              items: { type: "string" } 
            },
            emergencyAdvice: { type: "string" },
            preventionTips: { 
              type: "array", 
              items: { type: "string" } 
            },
            shouldSeekHelp: { type: "boolean" },
            followUpTime: { type: "string" }
          }
        }
      });

      setAiAnalysis(response);
    } catch (error) {
      console.error("Failed to analyze glucose:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getRiskColor = (level) => {
    switch (level) {
      case 'LOW': return 'bg-green-100 text-green-800 border-green-200';
      case 'MODERATE': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'HIGH': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'CRITICAL': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getRiskIcon = (level) => {
    switch (level) {
      case 'CRITICAL': return <AlertTriangle className="w-5 h-5" />;
      case 'HIGH': return <TrendingUp className="w-5 h-5" />;
      case 'MODERATE': return <TrendingDown className="w-5 h-5" />;
      default: return <Brain className="w-5 h-5" />;
    }
  };

  if (!currentBG) return null;

  return (
    <Card className={`border-2 ${
      aiAnalysis?.riskLevel === 'CRITICAL' ? 'border-red-300 shadow-red-100 shadow-lg animate-pulse' :
      aiAnalysis?.riskLevel === 'HIGH' ? 'border-orange-300 shadow-orange-100 shadow-lg' :
      'border-blue-200'
    }`}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold">AI Glucose Analysis</h3>
            {aiAnalysis && (
              <Badge className={`${getRiskColor(aiAnalysis.riskLevel)} border mt-1`}>
                {getRiskIcon(aiAnalysis.riskLevel)}
                <span className="ml-1">{aiAnalysis.riskLevel} RISK</span>
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {isAnalyzing ? (
          <div className="flex items-center gap-3 py-4">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-purple-600"></div>
            <span className="text-gray-600">AI is analyzing your glucose pattern...</span>
          </div>
        ) : aiAnalysis ? (
          <>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <p className="text-blue-900 font-medium mb-2">📊 Current Assessment</p>
              <p className="text-blue-800">{aiAnalysis.primaryMessage}</p>
            </div>

            {aiAnalysis.immediateActions && aiAnalysis.immediateActions.length > 0 && (
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <p className="text-green-900 font-medium mb-2">🎯 Take Action Now</p>
                <ul className="text-green-800 space-y-1">
                  {aiAnalysis.immediateActions.map((action, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-green-600 font-bold mt-0.5">•</span>
                      <span>{action}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {aiAnalysis.shouldSeekHelp && (
              <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                <p className="text-red-900 font-medium mb-2">🚨 Emergency Guidance</p>
                <p className="text-red-800 mb-3">{aiAnalysis.emergencyAdvice}</p>
                <Button className="bg-red-600 hover:bg-red-700 text-white">
                  <Phone className="w-4 h-4 mr-2" />
                  Call Emergency Services
                </Button>
              </div>
            )}

            {aiAnalysis.preventionTips && aiAnalysis.preventionTips.length > 0 && (
              <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <p className="text-purple-900 font-medium mb-2">💡 Prevention Tips</p>
                <ul className="text-purple-800 space-y-1 text-sm">
                  {aiAnalysis.preventionTips.map((tip, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-purple-600 font-bold mt-0.5">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {aiAnalysis.followUpTime && (
              <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                <p className="text-gray-700 text-sm">
                  ⏰ <strong>Check again:</strong> {aiAnalysis.followUpTime}
                </p>
              </div>
            )}
          </>
        ) : null}
      </CardContent>
    </Card>
  );
}