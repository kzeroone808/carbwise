import React, { useState, useEffect } from 'react';
import { InvokeLLM } from "@/api/integrations";
import { AlertTriangle, TrendingDown, TrendingUp, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';

export default function SmartAlerts({ currentBG, trend, previousBG, userTier = "free" }) {
  const [alerts, setAlerts] = useState([]);
  const [dismissedAlerts, setDismissedAlerts] = useState(new Set());

  useEffect(() => {
    if (currentBG) {
      checkForAlerts();
    }
  }, [currentBG, trend, previousBG, userTier]);

  const checkForAlerts = async () => {
    const newAlerts = [];

    // --- Basic Alerts (Available to all users) ---

    // Critical Low
    if (currentBG < 70) {
      newAlerts.push({
        id: 'critical_low',
        type: 'CRITICAL',
        title: 'Critical Low Blood Sugar',
        message: `Your BG is ${currentBG} mg/dL. Take action immediately.`,
        icon: AlertTriangle,
        color: 'red',
        action: 'Consume 15g of fast-acting carbs.'
      });
    }
    // Low warning
    else if (currentBG < 80) {
      newAlerts.push({
        id: 'low_warning',
        type: 'WARNING',
        title: 'Low Blood Sugar Warning',
        message: `Your BG is ${currentBG} mg/dL. Consider having a snack.`,
        icon: TrendingDown,
        color: 'yellow',
        action: 'Monitor closely.'
      });
    }

    // Critical High
    if (currentBG > 250) {
      newAlerts.push({
        id: 'critical_high',
        type: 'CRITICAL',
        title: 'High Blood Sugar Alert',
        message: `Your BG is ${currentBG} mg/dL. Check for ketones and consider a correction.`,
        icon: AlertTriangle,
        color: 'red',
        action: 'Stay hydrated and monitor ketones.'
      });
    }
    // High warning
    else if (currentBG > 180) {
      newAlerts.push({
        id: 'high_warning',
        type: 'WARNING',
        title: 'Elevated Blood Sugar',
        message: `Your BG is ${currentBG} mg/dL and above the target range.`,
        icon: TrendingUp,
        color: 'orange',
        action: 'Monitor closely.'
      });
    }

    // --- Smart AI-Powered Alerts (Premium Plus Only) ---
    if (userTier === 'premium_plus') {
        // Rapid rise detection
        if (previousBG && (currentBG - previousBG) > 40 && trend?.includes('Up')) {
          const rapidRiseAlert = await generateSmartAlert('rapid_rise', currentBG, previousBG, trend);
          if (rapidRiseAlert) newAlerts.push(rapidRiseAlert);
        }

        // Rapid drop detection
        if (previousBG && (previousBG - currentBG) > 40 && trend?.includes('Down')) {
          const rapidDropAlert = await generateSmartAlert('rapid_drop', currentBG, previousBG, trend);
          if (rapidDropAlert) newAlerts.push(rapidDropAlert);
        }
    }


    // Filter out dismissed alerts and duplicates, then update state
    const uniqueNewAlerts = newAlerts.filter((alert, index, self) =>
        index === self.findIndex((a) => (a.id === alert.id))
    );
    const activeAlerts = uniqueNewAlerts.filter(alert => !dismissedAlerts.has(alert.id));
    setAlerts(activeAlerts);
  };

  const generateSmartAlert = async (alertType, current, previous, trend) => {
    try {
      const prompt = `Generate a smart glucose alert for a user with diabetes. The user's current situation is:
      
Current BG: ${current} mg/dL
Previous BG (15 mins ago): ${previous} mg/dL
Trend: ${trend}
Alert Type: ${alertType}

Provide a brief, actionable alert message. The "title" should be a short, clear headline. The "message" should explain what's happening. The "action" should be a clear, simple instruction. The "urgency" must be LOW, MEDIUM, HIGH, or CRITICAL.`;

      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            message: { type: "string" },
            action: { type: "string" },
            urgency: { type: "string", enum: ["LOW", "MEDIUM", "HIGH", "CRITICAL"] }
          }
        }
      });

      return {
        id: alertType,
        type: response.urgency,
        title: response.title,
        message: response.message,
        action: response.action,
        icon: alertType.includes('drop') ? TrendingDown : TrendingUp,
        color: response.urgency === 'CRITICAL' ? 'red' : response.urgency === 'HIGH' ? 'orange' : 'yellow'
      };
    } catch (error) {
      console.error("Failed to generate smart alert:", error);
      return null;
    }
  };

  const dismissAlert = (alertId) => {
    setDismissedAlerts(prev => new Set(prev).add(alertId));
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  };

  const getAlertColors = (color) => {
    switch (color) {
      case 'red': return 'bg-red-100 border-red-500 text-red-900';
      case 'orange': return 'bg-orange-100 border-orange-500 text-orange-900';
      case 'yellow': return 'bg-yellow-100 border-yellow-500 text-yellow-900';
      default: return 'bg-blue-100 border-blue-500 text-blue-900';
    }
  };

  return (
    <div className="fixed top-4 right-4 z-[100] w-full max-w-sm space-y-2">
      <AnimatePresence>
        {alerts.map((alert) => {
          const IconComponent = alert.icon;
          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 100, transition: { duration: 0.2 } }}
              className={`border-l-4 p-4 rounded-lg shadow-xl ${getAlertColors(alert.color)} backdrop-blur-sm`}
            >
              <div className="flex items-start gap-3">
                <IconComponent className="w-5 h-5 mt-1 flex-shrink-0" />
                <div className="flex-1">
                  <h4 className="font-bold text-sm">{alert.title}</h4>
                  <p className="text-xs mt-1">{alert.message}</p>
                  {alert.action && (
                    <p className="text-xs font-semibold mt-2 bg-black/5 p-2 rounded">
                      {alert.action}
                    </p>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-1 h-auto -mr-2 -mt-2 opacity-60 hover:opacity-100"
                  onClick={() => dismissAlert(alert.id)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}