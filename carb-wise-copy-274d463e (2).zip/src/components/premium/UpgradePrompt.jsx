
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Zap, Star, Heart, Loader2 } from "lucide-react";
import { createCheckoutSession } from "@/api/functions";

export default function UpgradePrompt({ requiredTier, onUpgrade }) {
  const [isLoading, setIsLoading] = useState(false);

  const plans = {
    premium: {
      name: "Premium",
      price: "$4.99",
      icon: Crown,
      color: "yellow",
      benefits: [
        "6 Restaurant Picks", // Changed from "10 Restaurant Picks"
        "Live Blood Glucose Monitoring",
        "Advanced Insulin Calculator",
        "Meal History & Analytics",
        "Smart Menu Importer",
        "Priority Support"
      ]
    },
    premium_plus: {
      name: "Premium Plus",
      price: "$9.99",
      icon: Star,
      color: "purple",
      benefits: [
        "Unlimited Restaurant Access",
        "All Premium Features",
        "AI-Powered Glucose Analysis",
        "Smart Blood Sugar Alerts",
        "Predictive Health Insights",
        "Export Meal Data",
        "Early Access to New Features"
      ]
    }
  };

  const plan = plans[requiredTier];
  const IconComponent = plan.icon;

  const handleUpgrade = async () => {
    setIsLoading(true);
    try {
      const { data } = await createCheckoutSession({ plan: requiredTier });
      if (data && data.url) {
        window.location.href = data.url;
      } else {
        throw new Error('Could not create checkout session');
      }
    } catch (error) {
      console.error("Upgrade Error:", error);
      alert(`Error: ${error.message || 'Something went wrong. Please try again.'}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className={`w-16 h-16 bg-gradient-to-r from-${plan.color}-400 to-${plan.color}-600 rounded-full flex items-center justify-center mx-auto mb-4`}>
            <IconComponent className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold">Unlock {plan.name}</CardTitle>
          <p className="text-gray-600">Get advanced diabetes management features</p>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-gray-900">{plan.price}</div>
            <div className="text-sm text-gray-500">per month</div>
          </div>

          <div className="space-y-3">
            {plan.benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className={`w-5 h-5 bg-${plan.color}-100 rounded-full flex items-center justify-center`}>
                  <Heart className={`w-3 h-3 text-${plan.color}-600`} />
                </div>
                <span className="text-sm text-gray-700">{benefit}</span>
              </div>
            ))}
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-blue-900">Why upgrade?</span>
            </div>
            <p className="text-sm text-blue-700">
              {requiredTier === 'premium'
                ? 'Get live glucose monitoring and 6 restaurant picks for comprehensive diabetes management.' // Changed from "10 restaurant picks"
                : 'Unlock AI-powered glucose analysis and unlimited restaurant access for the ultimate diabetes care experience.'}
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => onUpgrade(false)}
              disabled={isLoading}
            >
              Maybe Later
            </Button>
            <Button
              onClick={handleUpgrade}
              disabled={isLoading}
              className={`flex-1 bg-gradient-to-r from-${plan.color}-500 to-${plan.color}-600 hover:from-${plan.color}-600 hover:to-${plan.color}-700`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                `Upgrade to ${plan.name}`
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
