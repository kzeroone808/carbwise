
import React, { useState, useEffect, useRef } from 'react';
import { ArrowUp, ArrowRight, ArrowDown, HelpCircle, ZapOff, Loader2, Brain, Crown, Settings, AlertTriangle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { fetchCGMData } from '@/api/functions';

const TrendArrow = ({ trend }) => {
  const trendMap = {
    'DoubleUp': <ArrowUp className="w-6 h-6" />,
    'SingleUp': <ArrowUp className="w-6 h-6" />,
    'FortyFiveUp': <ArrowUp className="w-6 h-6 rotate-45" />,
    'Flat': <ArrowRight className="w-6 h-6" />,
    'FortyFiveDown': <ArrowDown className="w-6 h-6 -rotate-45" />,
    'SingleDown': <ArrowDown className="w-6 h-6" />,
    'DoubleDown': <ArrowDown className="w-6 h-6" />,
  };
  return trendMap[trend] || <HelpCircle className="w-6 h-6" />;
};

export default function RealtimeBGDisplay({ onShowAI, userTier = "free", onReadingUpdate }) {
  const [status, setStatus] = useState('checking');
  const [reading, setReading] = useState(null);
  const [error, setError] = useState(null);
  const [lastFetchTime, setLastFetchTime] = useState(0);
  const [retryCount, setRetryCount] = useState(0);
  const intervalRef = useRef(null);

  useEffect(() => {
    // Initial check
    checkCGMConnection();
    
    // Set up interval to fetch data every 5 minutes (300 seconds) to avoid rate limiting
    intervalRef.current = setInterval(() => {
      if (status === 'connected') {
        checkCGMConnection();
      }
    }, 300000); // 5 minutes
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const checkCGMConnection = async () => {
    const now = Date.now();
    
    // Rate limiting: don't allow requests more than once every 2 minutes
    if (now - lastFetchTime < 120000) {
      console.log('Skipping CGM fetch due to rate limiting');
      return;
    }

    try {
      setStatus('loading');
      setLastFetchTime(now);
      
      const { data } = await fetchCGMData();
      
      if (data.success && data.reading) {
        setReading(data.reading);
        onReadingUpdate(data.reading);
        setStatus('connected');
        setError(null);
        setRetryCount(0); // Reset retry count on success
      } else {
        setReading(null);
        onReadingUpdate(null);
        
        if (data.error && data.error.includes('Rate limit')) {
          setStatus('rate_limited');
          setError('Rate limited - please wait before retrying');
        } else {
          setStatus('no_data');
          setError(data.error || 'No recent glucose data available');
        }
      }
    } catch (error) {
      console.error('CGM fetch error:', error);
      setReading(null);
      onReadingUpdate(null);
      
      // Handle different error types
      if (error.message && error.message.includes('429')) {
        setStatus('rate_limited');
        setError('Rate limited by Dexcom - please wait');
        setRetryCount(prev => prev + 1);
      } else if (error.message && error.message.includes('CGM not connected')) {
        setStatus('not_connected');
        setError('CGM not configured');
      } else {
        setStatus('error');
        setError('Connection failed');
      }
    }
  };

  const handleRetry = () => {
    // Only allow retry if it's been at least 2 minutes since last attempt
    const now = Date.now();
    if (now - lastFetchTime >= 120000) {
      checkCGMConnection();
    } else {
      const waitTime = Math.ceil((120000 - (now - lastFetchTime)) / 1000);
      setError(`Please wait ${waitTime} seconds before retrying`);
    }
  };

  const getBGColor = (value) => {
    if (value > 180) return 'text-red-600';
    if (value < 70) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getBGStatus = (value) => {
    if (value > 250) return { text: 'CRITICAL HIGH', color: 'bg-red-100 text-red-800' };
    if (value > 180) return { text: 'HIGH', color: 'bg-orange-100 text-orange-800' };
    if (value < 70) return { text: 'LOW', color: 'bg-yellow-100 text-yellow-800' };
    if (value < 80) return { text: 'WATCH', color: 'bg-yellow-100 text-yellow-800' };
    return { text: 'NORMAL', color: 'bg-green-100 text-green-800' };
  };

  const timeSince = (date) => {
    if (!date) return '';
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    const minutes = Math.floor(seconds / 60);
    if (minutes < 1) return "just now";
    if (minutes > 60) return `${Math.floor(minutes / 60)}h ${minutes % 60}m ago`;
    return `${minutes}m ago`;
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm">
      <CardContent className="p-4">
        {status === 'not_connected' && (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                <ZapOff className="w-6 h-6 text-gray-400" />
              </div>
              <div>
                <p className="font-semibold text-gray-800">Live Blood Glucose</p>
                <p className="text-sm text-gray-500">Connect your CGM to see live data</p>
              </div>
            </div>
            <Button asChild size="sm" variant="outline" className="w-full">
              <Link to={createPageUrl("CGMSettings")}>
                <Settings className="w-4 h-4 mr-2" />
                Connect Your CGM
              </Link>
            </Button>
          </div>
        )}
        
        {status === 'loading' && (
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
              <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />
            </div>
            <div>
              <p className="font-semibold text-gray-800">Fetching Data...</p>
              <p className="text-sm text-gray-500">Getting latest reading</p>
            </div>
          </div>
        )}

        {status === 'rate_limited' && (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-yellow-50 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-yellow-500" />
              </div>
              <div>
                <p className="font-semibold text-gray-800">Rate Limited</p>
                <p className="text-sm text-gray-500">Too many requests - CGM data updates every 5 minutes</p>
              </div>
            </div>
            <Button 
              size="sm" 
              variant="outline" 
              className="w-full"
              onClick={handleRetry}
              disabled={Date.now() - lastFetchTime < 120000}
            >
              Retry Connection
            </Button>
          </div>
        )}

        {(status === 'no_data' || status === 'error') && (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                <HelpCircle className="w-6 h-6 text-orange-500" />
              </div>
              <div>
                <p className="font-semibold text-gray-800">Connection Issue</p>
                <p className="text-sm text-gray-500">{error}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline" 
                className="flex-1"
                onClick={handleRetry}
                disabled={Date.now() - lastFetchTime < 120000}
              >
                Retry
              </Button>
              <Button asChild size="sm" variant="outline" className="flex-1">
                <Link to={createPageUrl("CGMSettings")}>
                  Settings
                </Link>
              </Button>
            </div>
          </div>
        )}
        
        {status === 'connected' && reading && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getBGColor(reading.value).replace('text-', 'bg-').replace('-600', '-50')}`}>
                  <span className={`text-2xl font-bold ${getBGColor(reading.value)}`}>
                    {reading.value}
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-gray-800">Current Glucose</p>
                    <Badge className={getBGStatus(reading.value).color}>
                      {getBGStatus(reading.value).text}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-500">{timeSince(reading.timestamp)}</p>
                </div>
              </div>
              <div className={`text-gray-700 ${getBGColor(reading.value)}`}>
                <TrendArrow trend={reading.trend} />
              </div>
            </div>
            
            <Button 
              onClick={onShowAI}
              variant="outline" 
              size="sm" 
              className={`w-full ${
                userTier === 'premium_plus' 
                  ? 'bg-gradient-to-r from-purple-50 to-blue-50 hover:from-purple-100 hover:to-blue-100 border-purple-200'
                  : 'bg-gradient-to-r from-gray-50 to-gray-100 border-gray-200'
              }`}
            >
              {userTier === 'premium_plus' ? (
                <>
                  <Brain className="w-4 h-4 mr-2 text-purple-600" />
                  <span className="text-purple-700">Get AI Analysis</span>
                </>
              ) : (
                <>
                  <Crown className="w-4 h-4 mr-2 text-yellow-600" />
                  <span className="text-gray-700">AI Analysis (Premium Plus)</span>
                </>
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
